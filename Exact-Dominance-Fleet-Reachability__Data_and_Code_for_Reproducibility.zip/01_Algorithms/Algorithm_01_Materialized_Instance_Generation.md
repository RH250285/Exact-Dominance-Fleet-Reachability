# Algorithm 1. Frozen Synthetic Instance Generation

**Require:** Families `FAMILIES`, integer seed `SEED = 2026112103`, and nine indexed cases per family.

**Ensure:** The 36 materialized cases and frozen SHA-256 protocol (already supplied; do not regenerate during review).

1. Set RNG ← `random.Random(SEED)`.
2. For each `family ∈ FAMILIES` and `idx ∈ {0,…,8}`, invoke `generate_case(family, idx, RNG)` in the frozen benchmark implementation.
3. Choose the family-dependent horizon, vehicle count, fees, movement radius, transport multiplier, budget, penalty, initial fleet and active sites as implemented.
4. For each period and scenario, sample the positive-demand path and correct all-zero scenario totals using the original deterministic rule.
5. Label split ← `development` if `idx < 6`; otherwise `evaluation`.
6. Materialize the case JSON and record its SHA-256 in `EXPERIMENT_PROTOCOL.json` before timing.
7. Freeze source code SHA-256 and instance hashes; never invoke `prepare` on an existing frozen study.

**Implementation:** `02_Python/fixed_dispatch_benchmark.py`: `generate_case`, `prepare`, `simplex`; exposed by `generators.py`.
