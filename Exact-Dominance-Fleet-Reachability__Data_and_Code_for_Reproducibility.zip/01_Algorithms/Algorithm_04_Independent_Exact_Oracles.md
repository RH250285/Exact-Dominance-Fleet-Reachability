# Algorithm 4. Independent Finite Verification and Policy-Tree Oracles

**Require:** independent structural-verification parameters embedded in the original source and/or J3 tiny oracle cases, exact arithmetic, original fixed signal kernel.

**Ensure:** Stored finite-validation outcomes and direct comparisons without relying on the theorem-guided solver as an oracle.

1. Enumerate exact fixed-total fleet candidates and independently compute movement-ball containment and knapsack/subset certificates; record F1–F4 discrepancies and boundary countermodels.
2. Construct a separately implemented fixed-dispatch `Fraction`-valued Bellman oracle and compare sufficient guarded conditions with exact continuation values.
3. For common-parent decision pools, enumerate feasible children, construct retained-witness comparisons and verify the minimum-preservation property.
4. For tiny benchmark cases, enumerate every complete, nonanticipative contingent policy tree by choosing one initial action and a branch-conditional next-period action for each possible signal.
5. Evaluate total expected cost by exact rational arithmetic and compare the minimum with each of the five frozen Bellman methods.
6. Write finite-validation records with original seeds; preserve actual stored JSON results.

**Implementation:** `02_Python/Verification/independent_exact_oracle.py`, `contingent_policy_oracle.py`, `boundary_counterexamples.py`, `large_integer_stress_test.py`; `02_Python/fixed_dispatch_benchmark.py`: `test_small_brute`, `policy_micro_oracle`.
**Scope:** Exhaustive finite checks support, but do not replace, mathematical proof.
