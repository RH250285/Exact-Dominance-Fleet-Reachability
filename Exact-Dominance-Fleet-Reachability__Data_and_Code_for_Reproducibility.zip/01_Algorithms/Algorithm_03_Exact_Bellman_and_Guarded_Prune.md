# Algorithm 3. Exact Bellman Recursion with Guarded Action Screening

**Require:** Fixed-dispatch problem `p`; one of `B0_EXACT`, `BTERM`, `BF1`, `BF2`, `BF3`; initial state and fixed signal likelihoods.

**Ensure:** Exact `Fraction` objective and lexicographically first minimum root action; statistics for all evaluated certificates.

1. Set independent memoization cache and all counters to empty for this solver run.
2. At state `(t,β,x,n,B,Q)`, return the cached value if present; otherwise compute `(h,B⁺)` using Algorithm 2.
3. If `t = T`, cache and return `h`.
4. Enumerate all feasible actions in the fixed order. Maintain a permanent list `retained`.
5. For each candidate action `B`, inspect preceding retained witnesses `A`:
   - `B0_EXACT`: never delete; `BTERM`: test only terminal successors;
   - for each possible next signal, compute the two successor dispatch outcomes and return a terminal exact difference or a nonterminal guarded bound;
   - `BF1`: full-ball reachability and `Γ` surcharge; `BF2`: affordable-action enumerative matching; `BF3`: all-active F3 knapsack plus metric surcharge, otherwise BF2 matching;
   - require all site, backlog, reachability and remaining-budget guards, with the original source's exact comparisons;
   - accumulate the parent expenditure difference and the probability-weighted branch bounds; delete only if the total bound is nonpositive and A remains retained.
6. For every retained action, evaluate its exact Bayesian successor values, the pathwise residual budget and conditional cost.
7. Cache the minimum exact value; at the root, select the first minimum action in the stable original action order.
8. Record states expanded, candidate/retained/pruned counts and certificate checks.

**Implementation:** `02_Python/fixed_dispatch_benchmark.py`: `Solver._branch_bound`, `Solver._deletable`, `Solver.value`.
**Scope:** This is fixed-dispatch adaptation, not jointly optimal routing. Branch outcomes are not deleted independently.
