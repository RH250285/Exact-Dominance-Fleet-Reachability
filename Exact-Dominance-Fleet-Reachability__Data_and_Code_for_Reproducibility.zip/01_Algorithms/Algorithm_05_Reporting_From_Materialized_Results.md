# Algorithm 5. Manuscript Table and Figure Reporting

**Require:** Materialized historical `Individual_Trial_Results.json`, `Per_Instance_Performance.json`, `Computational_Benchmark_Summary.json` and frozen experiment protocol.

**Ensure:** Table 1 and the current manuscript speed-ratio Figure 1, with values read from stored outputs.

1. Read materialized results and the method names without invoking the optimization solver.
2. For each method, aggregate stored expanded-state, pruned-action, runtime and certificate counters.
3. Read B0/method geometric speed ratios and instance-cluster bootstrap interval endpoints from the stored summary.
4. Write `Computational_Comparison_Source.csv` with one row per method and the source's exact numerical values.
5. Plot method ratios with their stored 95% interval bounds and a horizontal ratio-one reference line.
6. Preserve original figure and table outputs; the curated XLSX is a layout-only conversion of the original CSV, not a recomputed estimate.

**Implementation:** `02_Python/benchmark_reporting_source.py`; review adapter `02_Python/reporting.py`.
