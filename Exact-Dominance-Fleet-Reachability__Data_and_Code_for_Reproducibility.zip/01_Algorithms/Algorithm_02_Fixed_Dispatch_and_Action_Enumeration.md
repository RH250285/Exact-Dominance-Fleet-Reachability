# Algorithm 2. Fixed Dispatch and Feasible Action Enumeration

**Require:** A materialized case, state `(t, β, x, n, B, Q)`, fixed dispatcher rule and the materialized feasible fleets.

**Ensure:** Conditional immediate cost `h`, common post-dispatch backlog bundle `B⁺`, and deterministic ordered feasible adaptation actions.

1. For each demand node `j`, compute the common deliverable quantity as the minimum across scenario-indexed available demand-plus-backlog.
2. If `dispatcher = local`, assign locally up to fleet capacity; otherwise allocate in increasing `(distance, facility index)` order and accumulate routing-distance shipping cost.
3. Compute scenario-specific `B⁺` from the same shipment vector, conditional expected backlog penalty, and terminal penalty when `t = T`.
4. For every candidate binary active vector `z` with `z ≥ x` and every fleet `u` in the fixed-total integer simplex:
   - enforce fleet–site compatibility and `d(n,u) ≤ m`;
   - set expenditure `κ ← opening_cost(x,z) + λ d(n,u)`;
   - retain the action only when `κ ≤ Q`.
5. Check that the zero-cost hold action exists; sort feasible actions by `(κ,z,u)`.
6. Cache dispatch and action sets by their deterministic state keys.

**Implementation:** `02_Python/fixed_dispatch_benchmark.py`: `Problem.dispatch`, `Problem.actions`.
