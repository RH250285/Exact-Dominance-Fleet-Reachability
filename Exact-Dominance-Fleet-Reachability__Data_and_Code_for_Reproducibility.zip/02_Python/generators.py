#!/usr/bin/env python3
"""Read-only exposure of the existing frozen benchmark instance generator.

The materialized instances are included under 03_Data/Instances. No generated
replacement instances are created by importing this module.
"""
from fixed_dispatch_benchmark import FAMILIES, SEED, generate_case, simplex

__all__ = ["FAMILIES", "SEED", "generate_case", "simplex"]
