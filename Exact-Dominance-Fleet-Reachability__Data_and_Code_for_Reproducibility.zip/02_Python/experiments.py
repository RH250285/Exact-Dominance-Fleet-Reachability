#!/usr/bin/env python3
"""Review entry point for the byte-identical frozen computational benchmark source.

Inspection checks the source and materialized input hashes. An optional, explicit
`run` command copies inputs to an isolated directory before invoking the original
script, so supplied records are never overwritten.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SCIENCE_SOURCE = Path(__file__).with_name("fixed_dispatch_benchmark.py")
DATA = ROOT / "03_Data"

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def inspect():
    protocol = json.loads((DATA / "Protocol/EXPERIMENT_PROTOCOL.json").read_text())
    if digest(SCIENCE_SOURCE) != protocol["code_sha256_at_freeze"]:
        raise RuntimeError("Frozen scientific code SHA-256 mismatch")
    inputs = protocol["input_files_sha256"]
    if len(inputs) != 36:
        raise RuntimeError("Frozen dataset inventory is incomplete")
    for name, expected in inputs.items():
        path = DATA / "Instances" / name
        if not path.is_file() or digest(path) != expected:
            raise RuntimeError("Input SHA-256 mismatch: " + name)
    print("PASS: frozen source and 36 materialized inputs")

def isolated_run(destination):
    inspect()
    work = Path(destination).resolve()
    if work.exists():
        raise FileExistsError("Choose a new directory to avoid overwriting any results")
    for sub in ("code", "instances", "protocol", "raw"):
        (work / sub).mkdir(parents=True, exist_ok=True)
    shutil.copy2(SCIENCE_SOURCE, work / "code/fixed_dispatch_benchmark.py")
    for p in (DATA / "Instances").glob("*.json"):
        shutil.copy2(p, work / "instances" / p.name)
    for p in (DATA / "Protocol").glob("*.json"):
        shutil.copy2(p, work / "protocol" / p.name)
    subprocess.run([sys.executable, str(work / "code/fixed_dispatch_benchmark.py"), "run"],check=True)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", nargs="?", choices=("inspect", "run"), default="inspect")
    parser.add_argument("--output-dir", default="isolated_reexecution")
    args = parser.parse_args()
    if args.action == "inspect":
        inspect()
    else:
        isolated_run(args.output_dir)
