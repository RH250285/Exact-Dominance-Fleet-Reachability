#!/usr/bin/env python3
"""Independent finite exact oracle for KJM R001 structural verification (NOT source code from Skill01/02).
Exact integer fleet geometry, 0-1 subset optimization, binary hardness reduction,
Bayesian finite-state dynamic-program value checks and witness retention.
Python 3.11+ standard library only.
"""
from __future__ import annotations
from itertools import product, combinations
from functools import lru_cache
from fractions import Fraction as F
from math import comb
from collections import defaultdict
import random, time, json, csv, sys, pathlib, hashlib, math

HOME=pathlib.Path(__file__).resolve().parents[1]
RAW=HOME/'raw'; RAW.mkdir(exist_ok=True,parents=True)
SEED=20261121
rng=random.Random(SEED)

def fleets(k,N):
    if k==1:
        yield (N,); return
    for v in range(N+1):
        for w in fleets(k-1,N-v): yield (v,)+w

def dist(a,b):
    return sum(abs(x-y) for x,y in zip(a,b))//2

def radius(v,q,space):
    return [u for u in space if dist(u,v)<=q]

def ksubset(a,b,m):
    P=[i for i in range(len(a)) if b[i]>a[i]]
    C=sum(a)-m-1
    if C<0:return 0
    best=0
    for sel in product([0,1],repeat=len(P)):
        w=sum(a[i] for i,s in zip(P,sel) if s)
        p=sum(b[i]-a[i] for i,s in zip(P,sel) if s)
        if w<=C:best=max(best,p)
    return best

def kdp(a,b,m):
    cap=sum(a)-m-1
    if cap<0:return 0
    dp=[0]*(cap+1)
    for i in range(len(a)):
        if b[i]<=a[i]:continue
        weight=a[i];profit=b[i]-a[i]
        for q in range(cap,weight-1,-1): dp[q]=max(dp[q], dp[q-weight]+profit)
    return dp[cap]

def verify_f3():
    count=0; boundary=defaultdict(int)
    for k in range(1,5):
      for N in range(0,7):
       space=list(fleets(k,N))
       db={(a,b):dist(a,b) for a in space for b in space}
       for a in space:
        for b in space:
         Bdist=[db[b,u] for u in space]
         Adist=[db[a,u] for u in space]
         for m in range(N+1):
          K=ksubset(a,b,m); DP=kdp(a,b,m)
          assert DP==K,(k,N,a,b,m,DP,K)
          for r in range(m+1):
           exact=max((Adist[i] for i in range(len(space)) if Bdist[i]<=r),default=0)<=m
           formula=K<=m-r
           assert exact==formula,(k,N,a,b,m,r,K,exact,formula)
           count+=1
           if r==0:boundary['r0']+=1
           if m==N:boundary['mN']+=1
           if r==m:boundary['equalradius']+=1
           if N==0:boundary['N0']+=1
           if k==1:boundary['k1']+=1
           if any(a[i]==0 and b[i]>a[i] for i in range(k)):boundary['zero_weights']+=1
           if a!=b:boundary['unequal_fleet']+=1
    return {'exact_full_ball_vs_independent_subset_vs_knapsack_checks':count,'boundaries':dict(boundary),'errors':0}

def knapsack_reduction_test():
    # The decision on the LHS is tested in actual balls separately for small instances.
    ntrials=0; direct_ball=0; negative=0;positive=0
    # Small deterministic exhaustive base tasks n=1..2 with weights/profits in {1,2}.
    examples=[]
    for n in range(1,3):
      for wp in product(product((1,2),repeat=2),repeat=n):
        w=tuple(v[0] for v in wp);p=tuple(v[1] for v in wp)
        H=sum(w);J=sum(p)
        for W in range(H+1):
         for P in range(1,J+2):
          ks=any(sum(w[i] for i in range(n) if (mask>>i)&1)<=W and sum(p[i] for i in range(n) if (mask>>i)&1)>=P for mask in range(1<<n))
          a=w+(J,P); b=tuple(w[i]+p[i] for i in range(n))+(0,P)
          N=H+J+P;m=N-W-1;r=H+J-W
          assert sum(a)==sum(b)==N and 0<=r<=m<=N
          formula=ksubset(a,b,m)>m-r
          assert formula==ks,(n,w,p,W,P,ks,formula)
          space=list(fleets(n+2,N))
          truth=any(dist(u,b)<=r and dist(u,a)>m for u in space)
          assert truth==ks,(n,w,p,W,P,ks,truth)
          ntrials+=1;direct_ball+=1
          positive+=int(truth);negative+=int(not truth)
          if len(examples)<8:examples.append({'n':n,'w':w,'p':p,'W':W,'P':P,'yes':truth,'N':N,'m':m,'r':r})
    # Independent knapsack calculation for n=3..8, without combinatorially huge ball expansion.
    for _ in range(3500):
      n=rng.randrange(3,9)
      w=tuple(rng.randint(1,15) for _ in range(n));p=tuple(rng.randint(1,15) for _ in range(n))
      H=sum(w);J=sum(p);W=rng.randint(0,H);P=rng.randint(1,J+8)
      brute=any(sum(w[i] for i in range(n) if mask>>i&1)<=W and sum(p[i] for i in range(n) if mask>>i&1)>=P for mask in range(1<<n))
      a=w+(J,P);b=tuple(w[i]+p[i] for i in range(n))+(0,P)
      N=H+J+P;m=N-W-1;r=H+J-W
      assert kdp(a,b,m)==ksubset(a,b,m)
      assert (ksubset(a,b,m)>m-r)==brute
      ntrials+=1;positive+=int(brute);negative+=int(not brute)
    return {'total_reduction_tests':ntrials,'independent_direct_ball_noncontainment_tests':direct_ball,'independent_subset_only_tests':ntrials-direct_ball,'positive':positive,'negative':negative,'errors':0,'examples':examples}

LIK=((F(3,4),F(1,4)),(F(1,4),F(3,4))) # L[y][omega]; nondeterministic, exogenous signals

def belief_update(beta,y):
    pr=sum(beta[w]*LIK[y][w] for w in range(2))
    return pr, tuple(beta[w]*LIK[y][w]/pr for w in range(2))

class FixedDOracle:
 def __init__(self,k,N,T,demand,opening,penalty,m,lam,dispatch_mode="local"):
    self.k=k;self.N=N;self.T=T;self.dem=demand
    self.f=opening;self.pen=penalty;self.m=m;self.lam=lam;self.dispatch_mode=dispatch_mode
    self.space=tuple(fleets(k,N));self.cache={}
    self.belief=(F(1,2),F(1,2));self.calls=0
 def dispatch(self,t,beta,n,back):
    # Scenario-wise demand/backlogs are *not* observable to the dispatcher.
    # A deterministic common shipment is chosen using the public scenario bundle:
    # each node's deliverable quantity is capped by the minimum available
    # quantity across scenarios. The SAME shipment plan applies to all omega.
    requirements=tuple(min(back[w][j]+self.dem[t][w][j] for w in range(2)) for j in range(self.k))
    served=[0]*self.k;shipping=0
    if self.dispatch_mode=="local":
      for i in range(self.k):served[i]=min(n[i],requirements[i])
    elif self.dispatch_mode=="routing":
      cap=list(n)
      for j in range(self.k):
        need=requirements[j]
        for i in sorted(range(self.k), key=lambda i:(abs(i-j),i)):
          qty=min(cap[i],need);cap[i]-=qty;need-=qty
          served[j]+=qty
          shipping+=qty*(2*abs(i-j)+(i%2))
    else:raise ValueError(self.dispatch_mode)
    plus=tuple(tuple(back[w][j]+self.dem[t][w][j]-served[j] for j in range(self.k)) for w in range(2))
    h=shipping+sum(beta[w]*self.pen*sum(plus[w]) for w in range(2))
    return h,plus
    raise ValueError(self.dispatch_mode)
 def actions(self,x,n,Q):
    for z in product((0,1),repeat=self.k):
     if any(x[i]>z[i] for i in range(self.k)):continue
     open_cost=sum(self.f[i]*(z[i]-x[i]) for i in range(self.k))
     for u in self.space:
      if any(u[i]>0 and z[i]==0 for i in range(self.k)):continue
      d=dist(n,u)
      if d>self.m:continue
      kappa=open_cost+self.lam*d
      if kappa<=Q:yield (z,u,kappa)
 def value(self,t,beta,x,n,back,Q):
    key=(t,beta,x,n,back,Q)
    if key in self.cache:return self.cache[key]
    self.calls+=1
    h,plus=self.dispatch(t,beta,n,back)
    if t==self.T:
      v=h
    else:
      candidates=[]
      for z,u,kappa in self.actions(x,n,Q):
       cont=sum((belief_update(beta,y)[0]*self.value(t+1,belief_update(beta,y)[1],z,u,plus,Q-kappa) for y in range(2)),F(0))
       candidates.append(kappa+cont)
      assert len(candidates)>0
      v=h+min(candidates)
    self.cache[key]=v
    return v

def verify_F1_F2():
    metrics=defaultdict(int); counter=[]; tracked=[]; pair_checks=0
    for case in range(180):
      k=3;N=2 if case%2==0 else 3;T=1 if case<130 else 2
      space=list(fleets(k,N));m=rng.choice((0,1,2));m=min(N,m)
      opening=tuple(rng.randint(0,2) for _ in range(k))
      pen=rng.choice((1,2,3,5));lam=rng.choice((1,2))
      demands=[]
      for t in range(T+1):
       wlist=[]
       for w in range(2):
        wlist.append(tuple(rng.randint(0,2 if t>0 else 1) for _ in range(k)))
       demands.append(tuple(wlist))
      # Additionally construct synchronized time-0 signal in 25% by nulling initial demands.
      if case%4==0: demands[0]=((0,)*k,(0,)*k)
      oracle=FixedDOracle(k,N,T,tuple(demands),opening,pen,m,lam,dispatch_mode="routing" if case%3==0 else "local")
      zero_back=((0,)*k,(0,)*k)
      for j in range(30):
        a=rng.choice(space);b=rng.choice(space)
        # Choose opening sets, guarantee fleet support and active inclusion, partly non-all-active.
        xb=tuple(1 if b[i]>0 or rng.random()<.65 else 0 for i in range(k))
        xa=tuple(1 if a[i]>0 or xb[i] or rng.random()<.55 else 0 for i in range(k))
        if not all(xa[i]>=xb[i] for i in range(k)):continue
        QA=rng.randint(0,6);QB=rng.randint(0,5)
        beta=oracle.belief
        ha,pa=oracle.dispatch(0,beta,a,zero_back)
        hb,pb=oracle.dispatch(0,beta,b,zero_back)
        if pa!=pb:continue
        pair_checks+=1
        ballB=radius(b,m,space);ballA=radius(a,m,space)
        gamma=max([0]+[lam*dist(u,a)-lam*dist(u,b) for u in ballB])
        Bacts=list(oracle.actions(xb,b,QB))
        if not Bacts:raise AssertionError('no hold')
        BF=all(dist(a,u)<=m for z,u,c in Bacts)
        diff=[]
        for z,u,cB in Bacts:
          zA=tuple(max(xa[i],z[i]) for i in range(k))
          cA=sum(opening[i]*(zA[i]-xa[i]) for i in range(k))+lam*dist(a,u)
          diff.append(cA-cB)
        delta=max([0]+diff)
        f2=BF and QA>=QB+delta
        f1=(set(ballB)<=set(ballA)) and QA>=QB+gamma
        if f1:assert f2 and delta<=gamma
        if not (f1 or f2):continue
        va=oracle.value(0,beta,xa,a,zero_back,QA)
        vb=oracle.value(0,beta,xb,b,zero_back,QB)
        if f1:assert va-vb<=ha-hb+gamma,(case,j,'F1',a,b,va,vb,gamma)
        if f2:assert va-vb<=ha-hb+delta,(case,j,'F2',a,b,va,vb,delta)
        metrics['F1_certified']+=int(f1)
        metrics['F2_certified']+=int(f2)
        metrics['F2_only']+=int(f2 and not f1)
        metrics['different_origin']+=int(a!=b)
        metrics['nonzero_demand_at_t0']+=int(any(q>0 for d in demands[0] for q in d))
        metrics['nonzero_demand_after_t0']+=int(any(q>0 for ds in demands[1:] for d in ds for q in d))
        metrics['non_all_active']+=int(xb!=(1,1,1) or xa!=(1,1,1))
        metrics['three_period_certificates']+=int(T==2)
        metrics['positive_F2_surcharge']+=int(delta>0)
        metrics['nonzero_hA_minus_hB']+=int(ha!=hb)
        metrics['routing_dispatch_certificates']+=int(oracle.dispatch_mode=='routing')
        # Matched label guard G_A=0 G_B=positive covering positive differential exactly.
        Ga=0;Gb=max(0,math.ceil(ha+delta-hb))
        assert F(Ga)+ha+F(delta)<=F(Gb)+hb
        assert F(Ga)+va<=F(Gb)+vb
        metrics['retained_witness_checks']+=1
        if len(tracked)<12:tracked.append({'case':case,'k':k,'N':N,'T':T,'a':a,'b':b,'xA':xa,'xB':xb,'QA':QA,'QB':QB,'m':m,'F1':f1,'F2':f2,'hA':str(ha),'hB':str(hb),'gamma':gamma,'delta':delta,'VA':str(va),'VB':str(vb),'demands':demands})
      metrics['cases_with_full_pair_search']+=1
    metrics['synchronized_pairs_screened']=pair_checks
    metrics['errors']=0
    return dict(metrics),tracked

def retained_core_sanity():
    # General invariant independent of detailed model: a record discarded against an
    # extant retained direct witness has no smaller value than witness.
    N=5000
    for _ in range(N):
      records=[rng.randint(-50,100) for j in range(rng.randint(2,12))]
      core=[]
      for v in records:
       if not any(w<=v for w in core):core.append(v)
      assert min(core)==min(records)
    return N

def main():
    stamp=time.time()
    f3=verify_f3()
    f4=knapsack_reduction_test()
    f12,cases=verify_F1_F2()
    p=retained_core_sanity()
    x={'id':'J2-R001-KJM-20261121-01','seed':SEED,'methods':'independent standard-library integer fleet enumeration, independent subset enumeration and descending knapsack DP; exact Fraction Bayesian Bellman oracle with exogenous two-observation signal kernel, zero-backlog initial state, deterministic COMMON-SHIPMENT nonanticipative fixed dispatcher (scenario-minimum demand rule), independent archive-free implementation','F3':f3,'F4':f4,'F1_F2':f12,'permanent_core_generic_invariant_tests':p,'time_seconds':round(time.time()-stamp,3),'source_zip_not_imported':True,'note':'Finite tests substantiate specified models only; no finite test proves universal theorem. No frozen holdout or TGAD code imported.'}
    (RAW/'Exact_Validation_Summary.json').write_text(json.dumps(x,indent=2,default=list,ensure_ascii=False))
    (RAW/'Independent_Oracle_Examples.json').write_text(json.dumps(cases,indent=2,default=list,ensure_ascii=False))
    print(json.dumps(x,indent=2,ensure_ascii=False))

if __name__=='__main__':main()
