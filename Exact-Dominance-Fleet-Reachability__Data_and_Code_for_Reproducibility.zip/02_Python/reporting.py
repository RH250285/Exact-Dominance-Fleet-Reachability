#!/usr/bin/env python3
"""Read-only report source inspection or optional isolated result reconstruction.

The original reporting implementation (renamed benchmark_reporting_source.py) remains byte-identical.
This adapter never modifies the packaged materialized historical outputs.
"""
from pathlib import Path
import argparse
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL = Path(__file__).with_name("benchmark_reporting_source.py")
RAW = ROOT / "04_Results/Raw/Computational_Benchmark"

def inspect():
    required = ("Individual_Trial_Results.json", "Per_Instance_Performance.json", "Computational_Benchmark_Summary.json")
    if not ORIGINAL.is_file() or any(not (RAW / s).is_file() for s in required):
        raise FileNotFoundError("Stored report inputs or original reporting source missing")
    print("PASS: original reporting source and stored inputs present")

def isolated_rebuild(destination):
    inspect()
    work = Path(destination).resolve()
    if work.exists():
        raise FileExistsError("Choose an unused directory to preserve original results")
    for sub in ("code", "raw", "report", "figures", "protocol"):
        (work / sub).mkdir(parents=True, exist_ok=True)
    shutil.copy2(ORIGINAL, work / "code/benchmark_reporting_source.py")
    for package_name, original_name in (
        ("Individual_Trial_Results.json", "all_trials.json"),
        ("Per_Instance_Performance.json", "per_instance.json"),
        ("Computational_Benchmark_Summary.json", "J3_SUMMARY.json"),
    ):
        shutil.copy2(RAW / package_name, work / "raw" / original_name)
    shutil.copy2(ROOT / "03_Data/Protocol/EXPERIMENT_PROTOCOL.json",work / "protocol/EXPERIMENT_PROTOCOL.json")
    subprocess.run([sys.executable, str(work / "code/benchmark_reporting_source.py")], check=True)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action",nargs="?", choices=("inspect", "rebuild"), default="inspect")
    parser.add_argument("--output-dir",default="isolated_reporting")
    args = parser.parse_args()
    if args.action == "inspect":
        inspect()
    else:
        isolated_rebuild(args.output_dir)
