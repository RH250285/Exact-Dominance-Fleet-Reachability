#!/usr/bin/env python3
"""Read-only integrity and historical exact-agreement checks; Python stdlib only."""
import hashlib, json, pathlib, sys, collections
root=pathlib.Path(__file__).resolve().parents[1]
errors=[]
def check(ok, why):
    if not ok: errors.append(why)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def readj(path):return json.loads((root/path).read_text(encoding='utf8'))

# Strict SHA256 manifest of all packaged files excluding the manifest itself.
manifest=root/'SHA256SUMS.txt'
lines=[x for x in manifest.read_text(encoding='utf8').splitlines() if x.strip()]
covered=[]
for line in lines:
    h,rel=line.split('  ',1)
    p=root/rel
    covered.append(rel)
    check(p.is_file() and sha(p)==h,'SHA256 mismatch: '+rel)
all_files={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p!=manifest and '__pycache__' not in p.parts}
check(set(covered)==all_files,'Manifest inventory differs from files present')

# Original frozen J3 protocol and source code.
protocol=readj('J3/protocol/EXPERIMENT_PROTOCOL.json')
check(sha(root/'J3/code/j3_experiment.py')==protocol['code_sha256_at_freeze'],'J3 code source not at freeze hash')
check(len(protocol['input_files_sha256'])==36,'J3 protocol does not list 36 inputs')
for name,expected in protocol['input_files_sha256'].items():
    p=root/'J3/instances'/name
    check(p.is_file() and sha(p)==expected,'J3 instance hash mismatch: '+name)

# All J3 repetitions agree exactly with unpruned DP on matching instances.
rows=readj('J3/raw/all_trials.json')
check(len(rows)==540,'Trial count not 540')
methods={'B0_EXACT','BTERM','BF1','BF2','BF3'}
cases={row.get('case_id') for row in rows}
check(len(cases)==36,'Not 36 unique cases')
counts=collections.Counter((row.get('case_id'),row.get('mode'),row.get('repeat')) for row in rows)
check(len(counts)==540 and all(v==1 for v in counts.values()),'Duplicate/missing (case,mode,repeat) keys')
check(all({x['mode'] for x in rows if x['case_id']==case}==methods for case in cases),'Missing a method')
check(all(set(x['repeat'] for x in rows if x['case_id']==case)=={0,1,2} for case in cases),'Missing a repetition')
for case in cases:
    sub=[x for x in rows if x['case_id']==case]
    baseline=[x for x in sub if x['mode']=='B0_EXACT']
    if not baseline:continue
    objective=baseline[0]['value']; action=baseline[0]['root_action']
    check(all(x['value']==objective and x['root_action']==action for x in sub),'Exact objective / lex-first root mismatch in '+case)
summary=readj('J3/raw/J3_SUMMARY.json')
check(summary['total_runs']==540 and summary['instances']==36, 'J3 summary counts')
check(summary['exact_objective_mismatches']==0 and summary['root_action_mismatches']==0,'J3 historical mismatch summary')
check(summary['all_cases_positive_demands_each_scenario_each_period'] is True,'J3 positive-demand flag')
oracle=readj('J3/raw/independent_policy_oracle.json')
check(oracle['objective_mismatches']==0 and len(oracle['cases'])==12,'J3 independent policy oracle')

# Stored independent verification outcomes.
for f in ('j2_binary_large_summary.json','j2_directed_metrics_and_countermodels.json','j2_policy_tree_and_root_pool.json'):
    j=readj('J2/raw/'+f)
    check(j['errors']==0,'J2 original errors: '+f)
j2=readj('J2/raw/j2_exact_test_summary.json')
for group in ('F1_F2','F3','F4'):
    check(group in j2,'Missing J2 group '+group)

if errors:
    print('FAIL: '+str(len(errors))+' problems')
    for e in errors: print('  - '+e)
    sys.exit(1)
print('PASS: package SHA256, 36 frozen instances, 540 exact-agreement trials, 12 independent policy cases, J2 summaries')
