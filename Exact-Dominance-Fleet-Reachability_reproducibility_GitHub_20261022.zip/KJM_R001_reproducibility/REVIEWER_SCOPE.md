# Theorem-to-evidence map

| Mathematical statement | Source in reviewer package | Nature of evidence |
|---|---|---|
| F1: guarded continuation-value dominance | `J2/code/j2_independent_verifier.py`, `J2/report/J2_PROOF_LEDGER.csv`, `J2/raw/j2_exact_test_summary.json` | Finite exact checks supporting the manuscript proof, not substituting for it |
| F2: affordable-action matching and safe permanent-comparator pruning | `J2/code/j2_policy_pool_oracle.py`, J2 verification summaries | Finite matching and action-removal checks |
| F3: directed-metric surcharge and unequal-radius knapsack characterization | `J2/code/j2_boundary_challenges.py`, `J2/code/j2_independent_verifier.py` | Enumeration, exact subproblem checks and countermodels |
| F4: NP/coNP classification on variable-dimension binary inputs | `J2/code/j2_binary_large.py`, J2 report and ledger | Tests of the reduction's examples; complexity proof remains the manuscript's responsibility |
| Computational comparisons B0 / BTERM / BF1 / BF2 / BF3 | `J3/code/`, frozen `J3/instances/`, `J3/raw/`, `J3/report/J3_TABLE_MAIN.csv` | 36 instances, 540 full runs, exact objectives and root decisions |

The proof statements and assumptions must be read in the manuscript. No abstract inference about general worst-case speedups, generic dispatch control, or jointly optimized vehicle routing is supported by these files.
