# J3 — Supporting Computational Experiments for Theorem-Led KJM R001

**Run ID:** J3-R001-KJM-20261121-01  
**Status:** J3_SUPPORT_COMPLETE; NO_GENERAL_ACCELERATION_ESTABLISHED  
**Protocol:** KJM-R001-J3-SUPPORT-v1.0, SHA-256 `e6d0b800e85bc62b43c0eafa713eb0b48874313928f2dc9c2c3b843d6e87c50e`  
**Target manuscript:** *Exact Dominance Certificates and Budget-Restricted Fleet Reachability in Lagged Facility–Fleet Adaptation*  
**Date:** 21 November 2026

## 1. Position and scope

J3 provides *supporting*, distinct numerical evidence for the mathematics-led article based on F1–F4. It does **not** enter or override the blocked Skill03 E1–E3 algorithmic-release gate; the historical TGAD A5 `REPOSITION` and `EXPERIMENT_RELEASE NOT_READY` remain unchanged. The objective is to check exact Bellman optimality under physically certified action deletion and report the actual end-to-end cost of certification, rather than to manufacture a speedup claim. This stage used a fresh input generator with seed `2026112103`, no Skill02 holdout files, no source TGAD solver import, and no J2 oracle code import.

## 2. Fixed model and method definitions

All 36 instances have k=3 facilities, N∈{2,3} homogeneous vehicles, 2 latent demand scenarios, 2 possible signals per period, an exogenous binary signal kernel P(y|ω) whose diagonal probability is 3/4, and T∈{2,3} where decisions are made at t=0,...,T−1 and the final dispatch occurs at t=T. Each period has **strictly positive total demand for both scenarios**, including t=0. Current dispatch first serves common scenario-wise safely dispatchable demand and is a fixed H-D-compatible deterministic local or greedy-distance dispatcher. One identical shipment plan is used across latent scenarios before observing y. No jointly optimal routing, scenario-specific shipment decisions or endogenous observation is permitted.

The fleet reallocation cost is λ d(a,b), opening fees are nonnegative, zero-cost hold is feasible, and the pathwise residual budget is not exceeded. Current expected cost includes dispatch-dependent shipping and weighted backlog cost; the terminal stage additionally penalizes expected backlog. Signal Bayes updates and Bellman values use `fractions.Fraction` throughout.

All solvers use the same initial state, action ordering and data, but have independent memoization caches on each timed run:

1. **B0_EXACT:** complete exact memoized Bellman recursion with no deletion (strongest primary computational reference).
2. **BTERM:** exact terminal-child comparison only, a deliberately strong non-theorem screening ablation.
3. **BF1:** BTERM plus original F1 guarded equal-radius geometry and Γ reserve certificates for nonterminal successor states.
4. **BF2:** BTERM plus exact F2 affordable-action checker and Δ reserve certificates.
5. **BF3:** BTERM plus exact F3 knapsack reachability and metric surcharge if both compared child active sets are all-open; otherwise F2 complete enumerative check. No approximation and no unilateral guard removal.

At a given Bellman parent, witness A must be a preceding permanently retained root action. Deleting B requires that the weighted sum of certified successor value-difference bounds plus the parent immediate cost difference is nonpositive. This is the action-level consequence of F1/F2/F3 with a direct witness, **not** equality of child state values. Terminal branch differences are calculated exactly rather than using nonterminal structural bounds. The exact root optimum and the first minimum action under the stable order are checked against B0 for every run.

## 3. Frozen design and comparator fairness

The experiment protocol and all 36 input JSON files were generated and SHA-frozen **before any J3 timings were performed**. Four predeclared families, each with nine seeds (six designated development, three evaluation), were `slack_local`, `overload_routing`, `partial_opening`, and `long_horizon`. The outcomes are not used to tune the solver after the freeze. Each of five methods was run three times per instance, with cyclically rotated method order: 36 × 5 × 3 = **540 full solve runs**. Each runtime is from a warm Python process and includes the entire uncached solver and all certification checks, but excludes interpreter startup, input parsing and disk I/O. The primary paired timing statistic is the **geometric mean of B0/alternative using per-instance medians**. The 95% intervals were obtained with 1,200 instance-cluster bootstrap resamples (not 540 independent replicates). This is an exploratory interval, not a claim of general performance improvement.

A separate independently constructed exhaustive policy-tree oracle ran 12 very small k=2,N=1,T=2 instances, enumerating **85 complete nonanticipative contingent policies** in total; it verified the exact Bellman optimum against all five solver variants. The micro-oracle's tiny size limits the strength of this supplementary check.

## 4. Main measured results

**All 540 runs match B0 exactly in optimal value and lex-first root action.** No value or root decision mismatch occurred. All 12 independent policy cases agree (85 fully enumerated policies, 0 mismatches). No frozen Skill02 holdout was used.

| Method | B0 / method (95% instance CI) | Mean states | Mean actions pruned | Cases faster /36 |
|---|---:|---:|---:|---:|
| B0 — exact DP | 1.000 (reference) | 59.03 | 0.00 | — |
| Terminal only | 0.952 [0.897, 1.002] | 41.00 | 24.86 | 12/36 |
| F1 — guarded | 0.969 [0.933, 1.013] | 35.11 | 24.36 | 11/36 |
| F2 — budget-filtered | 0.983 [0.940, 1.024] | 34.08 | 25.14 | 15/36 |
| F3 — knapsack | 1.005 [0.959, 1.054] | 34.08 | 25.14 | 15/36 |

**Interpretation:** BF3 decreases mean expanded Bellman states from 59.03 to 34.08 per instance and prunes 25.14 evaluated candidate actions on average, while retaining the same optimal objective. However, its overall B0/BF3 geometric mean speed ratio is 1.005, with 95% bootstrap interval [0.959, 1.054], crossing 1. The evidence **does not establish a net wall-time advantage**; some families are slower. BTERM alone also prunes many terminal actions. F1/F2/F3 should not claim every deleted action as novel structural pruning. The marginal nonterminal structural effect is visible in the reduction of expanded states from 41.00 with BTERM to 34.08 under BF3, but these state counts are a measured property of these generated cases, not an asymptotic theorem.

### Family-specific ratios (B0/method)

| Family | F1 | F2 | F3 | Cases with F2 pruning |
|---|---:|---:|---:|---:|
| long_horizon | 0.976 | 1.051 | 1.073 | 9/9 |
| overload_routing | 0.971 | 0.973 | 0.991 | 9/9 |
| partial_opening | 0.967 | 0.948 | 1.006 | 8/9 |
| slack_local | 0.964 | 0.963 | 0.956 | 9/9 |

F2 and F3 make **identical deletion decisions on every tested instance** under this exact all-active metric specialization, while the F3 checker changes the computation needed to certify reachability. Their ratio BF2/BF3 is 1.023 across 36 instances. This result is implementation- and workload-specific and does not make the complexity NP-complete boundary disappear.

### Split check

The predetermined development split contains 24 cases, the evaluation split 12. For BF3, their B0/BF3 geometric mean speed ratios are 1.002 and 1.011, respectively. Neither split is evidence of a general improvement, given small sample size, noise and mixed families.

## 5. Mathematical implications and limitations

- F1 supports admissible nonterminal cross-action certificates with all its physical, dispatch, backlog and pathwise reserve guards intact. No guarantee for jointly optimal shipment routing follows.
- F2's affordable-action restriction can certify cases that equal-radius geometry F1 cannot. This benchmark does not establish superior algorithmic wall time relative to BF1; the exact-oracle role and theorem scope matter more than an unsupported efficiency headline.
- F3's exact knapsack reduction is exercised on the all-active uniform-metric subclass; an exact pseudo-polynomial checker remains compatible with F4's variable-k binary-input coNP-completeness result. No universal polynomial full-DP guarantee follows.
- A complete policy-tree oracle for all benchmark instances would be infeasible at a larger scale, so exact B0 agreement plus 12 separately enumerated tiny cases are the finite computational checks supplied here.
- The 36 main instances are very small (three facilities, up to three vehicles and four dispatch stages), measured in one Linux/Python environment, without a general MILP/MIP baseline and without measured memory peak. Results should not be extrapolated to realistic disaster networks.
- The dispatcher is fixed and deterministic by design. The word *routing* in family names means an H-D-compatible greedy-distance shipment rule, not an optimized multi-stop vehicle-routing problem.
- All previously recorded negative A3/A4 TGAD timing results remain valid separate historical evidence; this new J3 experiment cannot erase or revise those gates.

## 6. Suggested journal-safe conclusion

"On 36 newly generated positive-demand instances, the theorem-guided action filters preserved the exact Bellman objective and selected initial action in all 540 timed trials. The strongest F3-based filter reduced expanded states on average, yet the observed end-to-end speed ratio relative to unpruned exact dynamic programming was close to unity and its instance-bootstrap interval included one. The computational evidence therefore supports correctness and the practical realization of the mathematical dominance certificates, without demonstrating a general runtime improvement."

## 7. Reproducibility, source locks, next stage

- Run script: `python code/j3_experiment.py prepare` must only be used in an EMPTY work directory; packaged protocol is already frozen. Reproduction uses `python code/j3_experiment.py run` after verifying the code and all input hashes. Reporting-only: `python code/j3_reporting.py`.
- Protocol SHA-256: `e6d0b800e85bc62b43c0eafa713eb0b48874313928f2dc9c2c3b843d6e87c50e`.
- Frozen solver/generator SHA-256: `3fe10833c0e0b12c07533170cbe85bff91fb1f9f2856ff688296bfa8886c6110`.
- Environment: Python 3.13.5; Linux-6.18.57-x86_64-with-glibc2.41; 5 logical CPUs exposed to the runtime. Solver uses standard-library exact rationals. RNG seed 2026112103.
- Evidence files: `raw/all_trials.json` (540 records), `raw/per_instance.json`, `raw/J3_SUMMARY.json`, `raw/independent_policy_oracle.json`, `raw/benchmark_console.log`, 36 `instances/*.json`, 2 `figures/*.png`, protocol hash manifest.
- Upstream Skill01 source SHA-256: `70ca59c4f16fb83b3a2ae7fcfb503dbb029d12bb904ebda79fc0c3f6b336d89a`.
- J2 independently validated package SHA-256: `07e04b841fec477dcdb28e000cb2b07724f5bc403a98596388ac895e35f024d2`.
- Audit status: `J3_SUPPORT_COMPLETE`; `NO_GENERAL_ACCELERATION_ESTABLISHED`. Proceed to **J4: theory-led KJM manuscript drafting**. Do not relabel Skill02 algorithmic gate `REPOSITION` as a GO.
