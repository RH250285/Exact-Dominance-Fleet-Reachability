# KJM R001 J3 Supporting Experiment (2026-11-21)

The complete theory-led supporting benchmark is frozen. **Do not re-run `prepare`** on the included input set; it is deliberately immutable.

Reproduce with Python 3.11+ standard library:
```bash
python code/j3_experiment.py inspect
python code/j3_experiment.py run
```

This overwrites only `raw/` benchmark output, not source instances or protocol, and refuses any code/input hash drift. For independent formatting of the report, run `python code/j3_reporting.py` (requires matplotlib only to regenerate figures). Repeated timings will naturally change by machine and load.

Source proofs are in separate Skill01/J1 documents. J2 separately audited F1–F4. These numerical experiments do not supersede the earlier Skill02 REPOSITION / NOT_READY decision.

All 36 instances have positive demands at every period and latent scenario. Frozen old TGAD holdout was not used. The five methods agree in objective and first root action in all 540 timed runs. No statistically supported general speedup was found.

`MANIFEST_SHA256.txt` verifies all contents (except itself).
