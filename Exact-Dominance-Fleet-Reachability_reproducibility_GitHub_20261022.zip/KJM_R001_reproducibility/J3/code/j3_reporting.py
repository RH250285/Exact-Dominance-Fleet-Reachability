#!/usr/bin/env python3
"""Post-run reporting only, not a solver or modification of frozen protocol."""
import csv, hashlib, json, math, os, statistics, pathlib, platform, zipfile
P=pathlib.Path(__file__).resolve().parents[1]
S=json.loads((P/'raw/J3_SUMMARY.json').read_text()); raw=json.loads((P/'raw/all_trials.json').read_text()); per=json.loads((P/'raw/per_instance.json').read_text())
try:
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 have_mpl=True
except ImportError:have_mpl=False

def round3(x):return f'{x:.3f}'
methods=list(S['method_names']); names={'B0_EXACT':'B0 — exact DP','BTERM':'Terminal only','BF1':'F1 — guarded','BF2':'F2 — budget-filtered','BF3':'F3 — knapsack'}
M={}
for method in methods:
 samples=[r for r in raw if r['mode']==method]
 M[method]={'mean_states':statistics.mean(r['states'] for r in samples),'mean_pruned':statistics.mean(r['pruned_actions'] for r in samples),
 'mean_retained':statistics.mean(r['retained_actions'] for r in samples),'median_runtime_ms':statistics.median(r['runtime_ns'] for r in samples)/1e6,
 'fraction_any_pruning':sum(r['pruned_actions']>0 for r in samples)/len(samples),
 'mean_pairs':statistics.mean(r['pair_attempts'] for r in samples),
 'structural_branch_certs_total':sum(r['structural_branch_certs'] for r in samples),
 'terminal_pair_checks_total':sum(r['terminal_pair_checks'] for r in samples),
 'knapsack_cert_checks_total':sum(r['knapsack_cert_checks'] for r in samples)}
F3_vs_F2=math.exp(statistics.mean(math.log(r['methods']['BF2']['median_runtime_ns']/r['methods']['BF3']['median_runtime_ns']) for r in per))
summary_csv=P/'report/J3_TABLE_MAIN.csv'
with summary_csv.open('w',newline='') as fh:
 w=csv.writer(fh);w.writerow(['method','geometric_speed_B0_over_method','ci_lower','ci_upper','mean_expanded_states','mean_pruned_actions','median_full_solve_ms','instances_faster_than_B0'])
 for method in methods:
  q=S['ratio'].get(method,{});ci=S['bootstrap_ci'].get(method,{}).get('instance_cluster_bootstrap_95pct',[1,1]); w.writerow([method,q.get('geomean_B0_div_method',1),ci[0],ci[1],M[method]['mean_states'],M[method]['mean_pruned'],M[method]['median_runtime_ms'],q.get('instances_method_faster',None)])
if have_mpl:
  fig,ax=plt.subplots(figsize=(7.4,4.5)); labels=[names[m] for m in methods];vals=[M[m]['mean_states'] for m in methods]
  bars=ax.bar(labels,vals); ax.set_ylabel('Mean expanded Bellman states per instance');ax.set_ylim(0,max(vals)*1.18);ax.tick_params(axis='x',rotation=17)
  for b,v in zip(bars,vals): ax.text(b.get_x()+b.get_width()/2, v+0.7,f'{v:.1f}',ha='center',fontsize=9)
  fig.tight_layout();fig.savefig(P/'figures/Figure_J3_1_Expanded_States.png',dpi=200);plt.close(fig)
  fig,ax=plt.subplots(figsize=(7.4,4.5))
  labs=[names[m] for m in methods[1:]]
  vals=[S['ratio'][m]['geomean_B0_div_method'] for m in methods[1:]]
  los=[S['bootstrap_ci'][m]['instance_cluster_bootstrap_95pct'][0] for m in methods[1:]]
  his=[S['bootstrap_ci'][m]['instance_cluster_bootstrap_95pct'][1] for m in methods[1:]]
  x=list(range(len(labs)))
  ax.errorbar(x,vals,yerr=[[v-l for v,l in zip(vals,los)],[h-v for h,v in zip(his,vals)]],fmt='o',capsize=5)
  ax.axhline(1,linestyle='--',linewidth=1);ax.set_xticks(x,labs,rotation=16);ax.set_ylabel('Geometric mean speed ratio B0 / method (95% CI)')
  ax.set_ylim(0.85,1.10);fig.tight_layout();fig.savefig(P/'figures/Figure_J3_2_Paired_Speed_Ratios.png',dpi=200);plt.close(fig)

def table_str():
 out=['| Method | B0 / method (95% instance CI) | Mean states | Mean actions pruned | Cases faster /36 |','|---|---:|---:|---:|---:|']
 for m in methods:
  if m=='B0_EXACT':ratio='1.000 (reference)';fast='—'
  else:
   ci=S['bootstrap_ci'][m]['instance_cluster_bootstrap_95pct'];q=S['ratio'][m]
   ratio=f"{q['geomean_B0_div_method']:.3f} [{ci[0]:.3f}, {ci[1]:.3f}]";fast=f"{q['instances_method_faster']}/36"
  out.append(f"| {names[m]} | {ratio} | {M[m]['mean_states']:.2f} | {M[m]['mean_pruned']:.2f} | {fast} |")
 return '\n'.join(out)

family_text=[]
for fam in S['by_family']:
 qs=S['by_family'][fam]
 family_text.append(f"| {fam} | {qs['BF1']['geomean_B0_div_method']:.3f} | {qs['BF2']['geomean_B0_div_method']:.3f} | {qs['BF3']['geomean_B0_div_method']:.3f} | {qs['BF2']['instances_with_pruning']}/9 |")
md=f'''# J3 — Supporting Computational Experiments for Theorem-Led KJM R001

**Run ID:** J3-R001-KJM-20261121-01  
**Status:** J3_SUPPORT_COMPLETE; NO_GENERAL_ACCELERATION_ESTABLISHED  
**Protocol:** KJM-R001-J3-SUPPORT-v1.0, SHA-256 `{S['protocol_sha256']}`  
**Target manuscript:** *Exact Dominance Certificates and Budget-Restricted Fleet Reachability in Lagged Facility–Fleet Adaptation*  
**Date:** 21 November 2026

## 1. Position and scope

J3 provides *supporting*, distinct numerical evidence for the mathematics-led article based on F1–F4. It does **not** enter or override the blocked Skill03 E1–E3 algorithmic-release gate; the historical TGAD A5 `REPOSITION` and `EXPERIMENT_RELEASE NOT_READY` remain unchanged. The objective is to check exact Bellman optimality under physically certified action deletion and report the actual end-to-end cost of certification, rather than to manufacture a speedup claim. This stage used a fresh input generator with seed `2026112103`, no Skill02 holdout files, no source TGAD solver import, and no J2 oracle code import.

## 2. Fixed model and method definitions

All 36 instances have k=3 facilities, N∈{{2,3}} homogeneous vehicles, 2 latent demand scenarios, 2 possible signals per period, an exogenous binary signal kernel P(y|ω) whose diagonal probability is 3/4, and T∈{{2,3}} where decisions are made at t=0,...,T−1 and the final dispatch occurs at t=T. Each period has **strictly positive total demand for both scenarios**, including t=0. Current dispatch first serves common scenario-wise safely dispatchable demand and is a fixed H-D-compatible deterministic local or greedy-distance dispatcher. One identical shipment plan is used across latent scenarios before observing y. No jointly optimal routing, scenario-specific shipment decisions or endogenous observation is permitted.

The fleet reallocation cost is λ d(a,b), opening fees are nonnegative, zero-cost hold is feasible, and the pathwise residual budget is not exceeded. Current expected cost includes dispatch-dependent shipping and weighted backlog cost; the terminal stage additionally penalizes expected backlog. Signal Bayes updates and Bellman values use `fractions.Fraction` throughout.

All solvers use the same initial state, action ordering and data, but have independent memoization caches on each timed run:

1. **B0_EXACT:** complete exact memoized Bellman recursion with no deletion (strongest primary computational reference).
2. **BTERM:** exact terminal-child comparison only, a deliberately strong non-theorem screening ablation.
3. **BF1:** BTERM plus original F1 guarded equal-radius geometry and Γ reserve certificates for nonterminal successor states.
4. **BF2:** BTERM plus exact F2 affordable-action checker and Δ reserve certificates.
5. **BF3:** BTERM plus exact F3 knapsack reachability and metric surcharge if both compared child active sets are all-open; otherwise F2 complete enumerative check. No approximation and no unilateral guard removal.

At a given Bellman parent, witness A must be a preceding permanently retained root action. Deleting B requires that the weighted sum of certified successor value-difference bounds plus the parent immediate cost difference is nonpositive. This is the action-level consequence of F1/F2/F3 with a direct witness, **not** equality of child state values. Terminal branch differences are calculated exactly rather than using nonterminal structural bounds. The exact root optimum and the first minimum action under the stable order are checked against B0 for every run.

## 3. Frozen design and comparator fairness

The experiment protocol and all 36 input JSON files were generated and SHA-frozen **before any J3 timings were performed**. Four predeclared families, each with nine seeds (six designated development, three evaluation), were `slack_local`, `overload_routing`, `partial_opening`, and `long_horizon`. The outcomes are not used to tune the solver after the freeze. Each of five methods was run three times per instance, with cyclically rotated method order: 36 × 5 × 3 = **540 full solve runs**. Each runtime is from a warm Python process and includes the entire uncached solver and all certification checks, but excludes interpreter startup, input parsing and disk I/O. The primary paired timing statistic is the **geometric mean of B0/alternative using per-instance medians**. The 95% intervals were obtained with 1,200 instance-cluster bootstrap resamples (not 540 independent replicates). This is an exploratory interval, not a claim of general performance improvement.

A separate independently constructed exhaustive policy-tree oracle ran 12 very small k=2,N=1,T=2 instances, enumerating **85 complete nonanticipative contingent policies** in total; it verified the exact Bellman optimum against all five solver variants. The micro-oracle's tiny size limits the strength of this supplementary check.

## 4. Main measured results

**All 540 runs match B0 exactly in optimal value and lex-first root action.** No value or root decision mismatch occurred. All 12 independent policy cases agree (85 fully enumerated policies, 0 mismatches). No frozen Skill02 holdout was used.

{table_str()}

**Interpretation:** BF3 decreases mean expanded Bellman states from {M['B0_EXACT']['mean_states']:.2f} to {M['BF3']['mean_states']:.2f} per instance and prunes {M['BF3']['mean_pruned']:.2f} evaluated candidate actions on average, while retaining the same optimal objective. However, its overall B0/BF3 geometric mean speed ratio is {S['ratio']['BF3']['geomean_B0_div_method']:.3f}, with 95% bootstrap interval [{S['bootstrap_ci']['BF3']['instance_cluster_bootstrap_95pct'][0]:.3f}, {S['bootstrap_ci']['BF3']['instance_cluster_bootstrap_95pct'][1]:.3f}], crossing 1. The evidence **does not establish a net wall-time advantage**; some families are slower. BTERM alone also prunes many terminal actions. F1/F2/F3 should not claim every deleted action as novel structural pruning. The marginal nonterminal structural effect is visible in the reduction of expanded states from {M['BTERM']['mean_states']:.2f} with BTERM to {M['BF3']['mean_states']:.2f} under BF3, but these state counts are a measured property of these generated cases, not an asymptotic theorem.

### Family-specific ratios (B0/method)

| Family | F1 | F2 | F3 | Cases with F2 pruning |
|---|---:|---:|---:|---:|
{chr(10).join(family_text)}

F2 and F3 make **identical deletion decisions on every tested instance** under this exact all-active metric specialization, while the F3 checker changes the computation needed to certify reachability. Their ratio BF2/BF3 is {F3_vs_F2:.3f} across 36 instances. This result is implementation- and workload-specific and does not make the complexity NP-complete boundary disappear.

### Split check

The predetermined development split contains 24 cases, the evaluation split 12. For BF3, their B0/BF3 geometric mean speed ratios are {math.exp(statistics.mean(math.log(r['methods']['B0_EXACT']['median_runtime_ns']/r['methods']['BF3']['median_runtime_ns']) for r in per if r['split']=='development')):.3f} and {math.exp(statistics.mean(math.log(r['methods']['B0_EXACT']['median_runtime_ns']/r['methods']['BF3']['median_runtime_ns']) for r in per if r['split']=='evaluation')):.3f}, respectively. Neither split is evidence of a general improvement, given small sample size, noise and mixed families.

## 5. Mathematical implications and limitations

- F1 supports admissible nonterminal cross-action certificates with all its physical, dispatch, backlog and pathwise reserve guards intact. No guarantee for jointly optimal shipment routing follows.
- F2's affordable-action restriction can certify cases that equal-radius geometry F1 cannot. This benchmark does not establish superior algorithmic wall time relative to BF1; the exact-oracle role and theorem scope matter more than an unsupported efficiency headline.
- F3's exact knapsack reduction is exercised on the all-active uniform-metric subclass; an exact pseudo-polynomial checker remains compatible with F4's variable-k binary-input coNP-completeness result. No universal polynomial full-DP guarantee follows.
- A complete policy-tree oracle for all benchmark instances would be infeasible at a larger scale, so exact B0 agreement plus 12 separately enumerated tiny cases are the finite computational checks supplied here.
- The 36 main instances are very small (three facilities, up to three vehicles and four dispatch stages), measured in one Linux/Python environment, without a general MILP/MIP baseline and without measured memory peak. Results should not be extrapolated to realistic disaster networks.
- The dispatcher is fixed and deterministic by design. The word *routing* in family names means an H-D-compatible greedy-distance shipment rule, not an optimized multi-stop vehicle-routing problem.
- All previously recorded negative A3/A4 TGAD timing results remain valid separate historical evidence; this new J3 experiment cannot erase or revise those gates.

## 6. Suggested journal-safe conclusion

"On 36 newly generated positive-demand instances, the theorem-guided action filters preserved the exact Bellman objective and selected initial action in all 540 timed trials. The strongest F3-based filter reduced expanded states on average, yet the observed end-to-end speed ratio relative to unpruned exact dynamic programming was close to unity and its instance-bootstrap interval included one. The computational evidence therefore supports correctness and the practical realization of the mathematical dominance certificates, without demonstrating a general runtime improvement."

## 7. Reproducibility, source locks, next stage

- Run script: `python code/j3_experiment.py prepare` must only be used in an EMPTY work directory; packaged protocol is already frozen. Reproduction uses `python code/j3_experiment.py run` after verifying the code and all input hashes. Reporting-only: `python code/j3_reporting.py`.
- Protocol SHA-256: `{S['protocol_sha256']}`.
- Frozen solver/generator SHA-256: `{json.loads((P/'protocol/EXPERIMENT_PROTOCOL.json').read_text())['code_sha256_at_freeze']}`.
- Environment: Python {S['environment']['python']}; {S['environment']['OS']}; {S['environment']['cpu_count']} logical CPUs exposed to the runtime. Solver uses standard-library exact rationals. RNG seed {json.loads((P/'protocol/EXPERIMENT_PROTOCOL.json').read_text())['seed']}.
- Evidence files: `raw/all_trials.json` (540 records), `raw/per_instance.json`, `raw/J3_SUMMARY.json`, `raw/independent_policy_oracle.json`, `raw/benchmark_console.log`, 36 `instances/*.json`, 2 `figures/*.png`, protocol hash manifest.
- Upstream Skill01 source SHA-256: `70ca59c4f16fb83b3a2ae7fcfb503dbb029d12bb904ebda79fc0c3f6b336d89a`.
- J2 independently validated package SHA-256: `07e04b841fec477dcdb28e000cb2b07724f5bc403a98596388ac895e35f024d2`.
- Audit status: `J3_SUPPORT_COMPLETE`; `NO_GENERAL_ACCELERATION_ESTABLISHED`. Proceed to **J4: theory-led KJM manuscript drafting**. Do not relabel Skill02 algorithmic gate `REPOSITION` as a GO.
'''
(P/'report/J3_TECHNICAL_REPORT.md').write_text(md,encoding='utf-8')
# HTML has semantic headings, paragraphs, table, minimal academic formatting.
import html,re
htmlparts=[];inlist=False;intable=False
for line in md.splitlines():
 if not line.strip():
  if inlist:htmlparts.append('</ul>');inlist=False
  if intable:htmlparts.append('</table>');intable=False
  continue
 if line.startswith('|'):
  parts=[x.strip() for x in line.strip().strip('|').split('|')]
  if set(''.join(parts).strip()) <= set('-: '):continue
  if not intable:htmlparts.append('<table border="1" cellspacing="0" cellpadding="5">');intable=True
  tag='th' if ('Method' in line or 'Family' in line) else 'td'
  htmlparts.append('<tr>'+''.join('<'+tag+'>'+html.escape(c)+'</'+tag+'>' for c in parts)+'</tr>');continue
 if intable:htmlparts.append('</table>');intable=False
 if line.startswith('- '):
  if not inlist:htmlparts.append('<ul>');inlist=True
  htmlparts.append('<li>'+html.escape(line[2:])+'</li>');continue
 if inlist:htmlparts.append('</ul>');inlist=False
 if line.startswith('### '):htmlparts.append('<h3>'+html.escape(line[4:])+'</h3>')
 elif line.startswith('## '):htmlparts.append('<h2>'+html.escape(line[3:])+'</h2>')
 elif line.startswith('# '):htmlparts.append('<h1>'+html.escape(line[2:])+'</h1>')
 else:
  line=html.escape(line)
  line=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',line)
  line=re.sub(r'`(.+?)`',r'<code>\1</code>',line)
  htmlparts.append('<p>'+line+'</p>')
if inlist:htmlparts.append('</ul>')
if intable:htmlparts.append('</table>')
ht='<!doctype html><html lang="en"><head><meta charset="utf-8"><style>body{font-family:Arial,sans-serif;line-height:1.4;font-size:11pt;color:#1b2530}h1{font-size:19pt}h2{font-size:14pt;margin-top:20px}h3{font-size:12pt}table{border-collapse:collapse;width:100%;font-size:9pt}th{background:#eff3f6}th,td{border:1px solid #abb6c0;padding:5px}p{margin:5px 0}code{font-family:monospace}</style></head><body>'+ '\n'.join(htmlparts)+'</body></html>'
(P/'report/J3_TECHNICAL_REPORT.html').write_text(ht,encoding='utf-8')
# Journal-ready distinct section.
section='''# Computational illustrations and exact verification (KJM draft)

We evaluated the theorem-derived action-deletion certificates on 36 freshly generated finite-horizon facility–fleet adaptation instances with strictly positive demand in every period and latent scenario. The model used three facilities, two or three vehicles, irreversible facility opening, a pathwise relocation budget, a one-period action implementation lag, and an H-D-compatible deterministic dispatcher. All latent scenarios shared the same pre-signal shipment action. Each instance was solved using unpruned memoized Bellman dynamic programming (B0), terminal-only deletion (BTERM), and additional exact guarded pruning based on F1, F2, or the F3 budget-reachability knapsack certificate. Five methods, three repeats, and 36 instances yielded 540 complete solves. Every method returned the same exact rational objective and initial optimal action as B0; a separate exhaustive oracle over 85 complete nonanticipative policies in 12 tiny instances yielded no discrepancy.

The mean number of expanded states decreased from '''+f"{M['B0_EXACT']['mean_states']:.2f}"+''' under B0 to '''+f"{M['BF3']['mean_states']:.2f}"+''' with the F3-based filter. This reduction did not establish a net speed advantage. The geometric mean paired runtime ratio B0/BF3 was '''+f"{S['ratio']['BF3']['geomean_B0_div_method']:.3f}"+''' (95% instance-bootstrap confidence interval '''+f"[{S['bootstrap_ci']['BF3']['instance_cluster_bootstrap_95pct'][0]:.3f}, {S['bootstrap_ci']['BF3']['instance_cluster_bootstrap_95pct'][1]:.3f}]"+'''). Terminal-only deletion already accounts for much of the observed action reduction, and the additional structural checks incur overhead. Thus, these numerical results illustrate sound dominance certificates and their exact algorithmic implementation, but do not claim improved asymptotic complexity, general runtime acceleration, or validity for jointly optimized vehicle routing. The experiment protocol, seeds, programs and all raw timings are archived in the J3 reproducibility package.
'''
(P/'report/J3_KJM_MANUSCRIPT_SECTION_EN.md').write_text(section,encoding='utf-8')
state={'run_id':'J3-R001-KJM-20261121-01','status':'J3_SUPPORT_COMPLETE','no_general_acceleration_established':True,
 'ready_for':'J4_THEORY_LED_MANUSCRIPT_DRAFT','skill02_a5_unchanged':'REPOSITION','skill02_experiment_release_unchanged':'NOT_READY',
 'frozen_tgad_holdout_used':False,'protocol_sha256':S['protocol_sha256'],'primary_mismatches':0,'complete_runs':540,
 'figures_created':have_mpl}
(P/'J3_STAGE_STATE.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
(P/'README.md').write_text('''# KJM R001 J3 Supporting Experiment (2026-11-21)\n\nThe complete theory-led supporting benchmark is frozen. **Do not re-run `prepare`** on the included input set; it is deliberately immutable.\n\nReproduce with Python 3.11+ standard library:\n```bash\npython code/j3_experiment.py inspect\npython code/j3_experiment.py run\n```\n\nThis overwrites only `raw/` benchmark output, not source instances or protocol, and refuses any code/input hash drift. For independent formatting of the report, run `python code/j3_reporting.py` (requires matplotlib only to regenerate figures). Repeated timings will naturally change by machine and load.\n\nSource proofs are in separate Skill01/J1 documents. J2 separately audited F1–F4. These numerical experiments do not supersede the earlier Skill02 REPOSITION / NOT_READY decision.\n\nAll 36 instances have positive demands at every period and latent scenario. Frozen old TGAD holdout was not used. The five methods agree in objective and first root action in all 540 timed runs. No statistically supported general speedup was found.\n\n`MANIFEST_SHA256.txt` verifies all contents (except itself).\n''',encoding='utf-8')
# all outputs except pycache and manifest; filenames and hashes of code, data, report and figures
with (P/'MANIFEST_SHA256.txt').open('w') as f:
 import hashlib
 for path in sorted(P.rglob('*')):
  if not path.is_file() or path.name=='MANIFEST_SHA256.txt' or '__pycache__' in path.parts:continue
  sha=hashlib.sha256(path.read_bytes()).hexdigest();f.write(f'{sha}  {path.relative_to(P)}\n')
print('J3 report ready; summary tables, figures, manuscript section and manifest created. F3/F2 geomean ratio=',F3_vs_F2)
