#!/usr/bin/env python3
"""KJM R001 J3: separate finite fixed-dispatch synthetic experiment.

No TGAD holdout inputs, no reuse/import of TGAD or J2 solver code. Python >=3.11
stdlib. All exact decisions/certificates use fractions and integers. Only wall-time
measurements are non-exact. This is an algorithmic consequence test, not a proof.
"""
import argparse, hashlib, itertools, json, math, os, platform, random, statistics, sys, time
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
PROTOCOL=BASE/'protocol'/'EXPERIMENT_PROTOCOL.json'
SEED=2026112103
LIK=((F(3,4),F(1,4)), (F(1,4),F(3,4))) # P(y|omega)
METHODS=('B0_EXACT','BTERM','BF1','BF2','BF3')
FAMILIES=('slack_local','overload_routing','partial_opening','long_horizon')

def simplex(k,n):
    if k==1:
        yield (n,)
    else:
        for v in range(n+1):
            for rest in simplex(k-1,n-v):
                yield (v,)+rest

def distance(a,b):
    return sum(abs(i-j) for i,j in zip(a,b))//2

def likelihood(beta,y):
    p=sum(beta[w]*LIK[y][w] for w in range(2))
    assert p>0
    return p,tuple(beta[w]*LIK[y][w]/p for w in range(2))

def support_knapsack(a,b,m):
    """NPS F3 geometry certificate: positive discrepancies, subset capacity."""
    cap=sum(a)-m-1
    if cap<0:return 0
    dp=[0]*(cap+1)
    for v,w in zip(a,b):
        if w<=v:continue
        for j in range(cap,v-1,-1):
            dp[j]=max(dp[j],dp[j-v]+w-v)
    return dp[cap]

def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha_file(p):return sha_bytes(Path(p).read_bytes())
def dump(path,obj):Path(path).write_text(json.dumps(obj,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')

def generate_case(family,idx,rng):
    k=3
    T=3 if family=='long_horizon' else 2
    N=2 if family in ('overload_routing','partial_opening','long_horizon') else 3
    f=(0,0,0) if family in ('slack_local','overload_routing','long_horizon') else tuple(rng.randint(1,4) for _ in range(k))
    n=rng.choice(tuple(simplex(k,N)))
    if family=='partial_opening':
        x=tuple(1 if n[i]>0 or rng.random()<.25 else 0 for i in range(k))
    else:x=(1,)*k
    m=1 if family in ('overload_routing','long_horizon') else rng.choice((1,2))
    lam=rng.choice((1,2))
    Q=rng.choice((2,3,4,5)) if family!='partial_opening' else rng.choice((1,2,3,4,5))
    penalty=rng.choice((2,4,8))
    demand=[]
    for t in range(T+1):
        if family=='slack_local':
            base=[rng.randint(0,1) for _ in range(k)]
            scenario=[tuple(base[j]+rng.randint(0,1) for j in range(k)) for _ in range(2)]
        elif family=='overload_routing':
            scenario=[tuple(rng.randint(1,3) for _ in range(k)) for _ in range(2)]
        elif family=='partial_opening':
            scenario=[tuple(rng.randint(0,2) for _ in range(k)) for _ in range(2)]
        else:
            scenario=[tuple(rng.randint(0,2) for _ in range(k)) for _ in range(2)]
        # Every period has genuinely positive demand in both latent scenarios.
        if not any(scenario[w][j]>0 for j in range(k) for w in range(2)):
            scenario[0]=tuple((1 if j==0 else 0) for j in range(k))
            scenario[1]=tuple((1 if j==0 else 0) for j in range(k))
        for w in range(2):
            if sum(scenario[w])==0:
                s=list(scenario[w]);s[rng.randrange(k)]=1;scenario[w]=tuple(s)
        demand.append(scenario)
    return {'case_id':f'{family}-{idx:02d}','family':family,'split':'development' if idx<6 else 'evaluation',
      'k':k,'N':N,'T':T,'m':m,'lambda':lam,'Q0':Q,'penalty':penalty,
      'opening':f,'n0':n,'x0':x,'demand':demand,
      'dispatcher':'local' if family in ('slack_local','partial_opening') else 'routing'}

@dataclass(frozen=True)
class Action:
    z:tuple
    u:tuple
    kappa:int

class Problem:
    def __init__(self, config):
        self.C=config;self.k=config['k'];self.N=config['N'];self.T=config['T'];self.m=config['m'];
        self.lam=config['lambda'];self.penalty=config['penalty'];self.opening=tuple(config['opening'])
        self.demand=config['demand'];self.dispatcher=config['dispatcher'];self.fleets=tuple(simplex(self.k,self.N))
        self.initial=(0,(F(1,2),F(1,2)),tuple(config['x0']),tuple(config['n0']),
                      tuple((0,)*self.k for _ in range(2)),config['Q0'])
        self._d_cache={}
        self._a_cache={}
    def dispatch(self,t,beta,n,back):
        key=(t,beta,n,back)
        if key in self._d_cache:return self._d_cache[key]
        # All shipments are COMMON across latent omega. They depend on public
        # scenario-indexed backlog and beta but not on realised omega.
        deliverable=tuple(min(back[w][j]+self.demand[t][w][j] for w in range(2)) for j in range(self.k))
        moved=[0]*self.k
        ship=0
        if self.dispatcher=='local':
            for i in range(self.k):moved[i]=min(n[i],deliverable[i])
        else:
            cap=list(n)
            for j in range(self.k):
                need=deliverable[j]
                for i in sorted(range(self.k),key=lambda i:(abs(i-j),i)):
                    load=min(need,cap[i]);need-=load;cap[i]-=load;moved[j]+=load
                    ship+=load*(2*abs(i-j)+(i%2))
        plus=tuple(tuple(back[w][j]+self.demand[t][w][j]-moved[j] for j in range(self.k)) for w in range(2))
        exp_backlog=sum(beta[w]*sum(plus[w]) for w in range(2))
        h=F(ship)+self.penalty*exp_backlog
        if t==self.T: h+=self.penalty*exp_backlog # terminal penalty only on backlog
        self._d_cache[key]=(h,plus)
        return h,plus
    def actions(self,x,n,Q):
        key=(x,n,Q)
        if key in self._a_cache:return self._a_cache[key]
        acts=[]
        for z in itertools.product((0,1),repeat=self.k):
            if any(z[i]<x[i] for i in range(self.k)):continue
            opening=sum(self.opening[i]*(z[i]-x[i]) for i in range(self.k))
            for u in self.fleets:
                if any(u[i]>0 and z[i]==0 for i in range(self.k)):continue
                d=distance(n,u)
                if d>self.m:continue
                cost=opening+self.lam*d
                if cost<=Q:acts.append(Action(z,u,cost))
        assert any(a.z==x and a.u==n and a.kappa==0 for a in acts)
        acts.sort(key=lambda a:(a.kappa,a.z,a.u))
        self._a_cache[key]=tuple(acts)
        return self._a_cache[key]

class Solver:
    def __init__(self,p,method):
        assert method in METHODS
        self.p=p;self.method=method;self.cache={};self.stats=defaultdict(int)
        self.last_root_action=None
    def _branch_bound(self,t,plus,by,A,B,QA,QB):
        p=self.p
        hA,pa=p.dispatch(t+1,by,A.u,plus)
        hB,pb=p.dispatch(t+1,by,B.u,plus)
        if t+1==p.T:
            self.stats['terminal_pair_checks']+=1
            return hA-hB
        if self.method in ('B0_EXACT','BTERM'):return None
        if any(A.z[i]<B.z[i] for i in range(p.k)):return None
        if pa!=pb:return None
        if self.method=='BF1':
            targets=[u for u in p.fleets if distance(B.u,u)<=p.m]
            if any(distance(A.u,u)>p.m for u in targets):return None
            surcharge=max([0]+[p.lam*(distance(A.u,u)-distance(B.u,u)) for u in targets])
        elif self.method=='BF3' and all(A.z) and all(B.z):
            rB=min(p.m,QB//p.lam)
            if support_knapsack(A.u,B.u,p.m)>p.m-rB:return None
            surcharge=p.lam*distance(A.u,B.u)
            self.stats['knapsack_cert_checks']+=1
        else:
            surcharge=0
            for beta_action in p.actions(B.z,B.u,QB):
                if distance(A.u,beta_action.u)>p.m:return None
                zmatch=tuple(max(A.z[i],beta_action.z[i]) for i in range(p.k))
                ca=sum(p.opening[i]*(zmatch[i]-A.z[i]) for i in range(p.k))+p.lam*distance(A.u,beta_action.u)
                surcharge=max(surcharge,ca-beta_action.kappa)
            self.stats['enumerative_cert_checks']+=1
        if QA<QB+surcharge:return None
        self.stats['structural_branch_certs']+=1
        return hA-hB+surcharge
    def _deletable(self,t,beta,plus,A,B,Q):
        p=self.p
        if self.method=='B0_EXACT':return False
        if self.method=='BTERM' and t+1!=p.T:return False
        self.stats['pair_attempts']+=1
        QA=Q-A.kappa;QB=Q-B.kappa
        bound=F(A.kappa-B.kappa)
        for y in (0,1):
            py,by=likelihood(beta,y)
            d=self._branch_bound(t,plus,by,A,B,QA,QB)
            if d is None:return False
            bound+=py*d
        if bound<=0:
            self.stats['pruned']+=1
            if t+1==p.T:self.stats['terminal_pruned']+=1
            else:self.stats['structural_pruned']+=1
            return True
        return False
    def value(self,t,beta,x,n,back,Q):
        key=(t,beta,x,n,back,Q)
        if key in self.cache:return self.cache[key]
        self.stats['expanded_states']+=1
        h,plus=self.p.dispatch(t,beta,n,back)
        if t==self.p.T:
            self.cache[key]=h
            return h
        pool=self.p.actions(x,n,Q)
        self.stats['candidate_actions']+=len(pool)
        retain=[]
        for B in pool:
            if any(self._deletable(t,beta,plus,A,B,Q) for A in retain):continue
            retain.append(B)
        self.stats['retained_actions']+=len(retain)
        vals=[]
        for alpha in retain:
            cont=sum((likelihood(beta,y)[0]*self.value(t+1,likelihood(beta,y)[1],alpha.z,alpha.u,plus,Q-alpha.kappa) for y in (0,1)),F(0))
            vals.append((h+alpha.kappa+cont,alpha))
        assert vals
        best=min(v for v,a in vals)
        act=next(a for v,a in vals if v==best)
        self.cache[key]=best
        if t==0:self.last_root_action=act
        return best

def test_small_brute(case):
    """Independent exhaustive complete 3-period nonanticipative policy-tree oracle."""
    p=Problem(case); assert p.T==2
    t,b,x,n,back,Q=p.initial
    h0,b0=p.dispatch(t,b,n,back)
    sols=[];ct=0
    for a0 in p.actions(x,n,Q):
        branches=[]
        for y in (0,1):
            py,by=likelihood(b,y)
            h1,b1=p.dispatch(1,by,a0.u,b0)
            options=[]
            for a1 in p.actions(a0.z,a0.u,Q-a0.kappa):
                inner=F(0)
                for y2 in (0,1):
                    py2,by2=likelihood(by,y2)
                    h2,b2=p.dispatch(2,by2,a1.u,b1)
                    inner+=py2*h2
                options.append((h1+a1.kappa+inner,a1))
            branches.append((py,options))
        for (v0,a0_branch),(v1,a1_branch) in itertools.product(branches[0][1],branches[1][1]):
            ct+=1
            sols.append(h0+a0.kappa+branches[0][0]*v0+branches[1][0]*v1)
    assert sols and ct
    return min(sols),ct

def prepare():
    assert not PROTOCOL.exists(), 'Protocol already exists; immutable data must not be regenerated'
    rng=random.Random(SEED)
    data=[]
    for family in FAMILIES:
        for i in range(9):
            c=generate_case(family,i,rng)
            assert all(sum(c['demand'][t][w])>0 for t in range(c['T']+1) for w in range(2))
            data.append(c)
            dump(BASE/'instances'/f"{c['case_id']}.json",c)
    proto={
      'protocol_id':'KJM-R001-J3-SUPPORT-v1.0','frozen_on':'2026-11-21','seed':SEED,
      'independent_of':'Skill02 TGAD frozen final holdout; all instances freshly generated with new seed',
      'problem':'Finite lag-one fixed-H-D dispatcher, nonanticipative common shipments, 2 latent scenarios, 2 binary signals with likelihoods 3/4 and 1/4, scenario-indexed backlog, irreversible facilities, uniform fleet movement and pathwise budget',
      'methods':METHODS,'families':FAMILIES,'instances_per_family':9,'split':{'development_index':'00..05','evaluation_index':'06..08'},
      'total_instances':len(data),'repetitions':3,'no_tuning_after_freeze':True,
      'timing':'Warm-process perf_counter_ns, separate per-method solver with empty caches, includes all DP/certification work (not Python interpreter startup or file I/O); deterministic cyclic method order',
      'primary_accuracy':'Fraction-equality of conditional optimal objective and lex-first root decision vs full memoized unpruned DP; every case must agree',
      'secondary_metrics':['full solve runtime ns','expanded states','candidate actions','retained actions','pruned actions','pair checks','branch certificates'],
      'no_performance_claim':'No a-priori assertion of net speedup, improvement in asymptotic DP complexity, or joint routing optimality',
      'independent_policy_oracle':'12 additional tiny synthetic k2,N1,T2 cases with complete nonanticipative contingent policy trees',
      'code_sha256_at_freeze':sha_file(Path(__file__)),
      'source_archive_sha256':'70ca59c4f16fb83b3a2ae7fcfb503dbb029d12bb904ebda79fc0c3f6b336d89a',
      'j2_archive_sha256':'07e04b841fec477dcdb28e000cb2b07724f5bc403a98596388ac895e35f024d2',
      'input_files_sha256':{p.name:sha_file(p) for p in sorted((BASE/'instances').glob('*.json'))},
      'analysis_predeclared':['paired geometric speed ratio B0/method','aggregate action-pruning ratio','per-family splits','objective mismatch and optimal root mismatch','independent full policy equality','negative results explicitly retained']
    }
    dump(PROTOCOL,proto)
    dump(BASE/'protocol'/'FREEZE_RECEIPT.json',{'protocol_sha256':sha_file(PROTOCOL),'input_count':len(data),'code_sha256':proto['code_sha256_at_freeze'],'split_sizes':{'development':24,'evaluation':12}})
    print('PREPARED',len(data),'instances; protocol sha256',sha_file(PROTOCOL))

def check_freeze():
    protocol=json.loads(PROTOCOL.read_text())
    assert len(protocol['input_files_sha256'])==protocol['total_instances']==36
    assert sha_file(Path(__file__))==protocol['code_sha256_at_freeze'],'Code changed after freeze; abort run'
    for name,hashval in protocol['input_files_sha256'].items():
        assert sha_file(BASE/'instances'/name)==hashval, 'Input changed: '+name
    return protocol

def policy_micro_oracle():
    R=random.Random(SEED+1701)
    records=[];total_policies=0
    for i in range(12):
        k=2;N=1;T=2
        n=R.choice(tuple(simplex(k,N)))
        x=tuple(1 if n[j]>0 or R.random()<.5 else 0 for j in range(k))
        dem=[]
        for t in range(3):
            pair=[]
            for w in range(2):
                v=tuple(R.randint(0,2) for j in range(k))
                if sum(v)==0:v=(1,0)
                pair.append(v)
            dem.append(pair)
        c={'case_id':'independent_policy_micro-'+str(i),'family':'independent_policy_micro','k':k,'N':N,'T':T,'m':1,'lambda':R.randint(1,2),'Q0':R.randint(0,3),'penalty':R.choice((2,4,6)),'opening':[R.randint(0,2) for _ in range(k)],'n0':n,'x0':x,'demand':dem,'dispatcher':('local' if i%2 else 'routing')}
        brute,npol=test_small_brute(c)
        baseline=Solver(Problem(c),'B0_EXACT');dp=baseline.value(*baseline.p.initial)
        assert brute==dp,(i,brute,dp)
        for method in METHODS[1:]:
            s=Solver(Problem(c),method)
            assert s.value(*s.p.initial)==brute,(i,method)
        total_policies+=npol
        records.append({'id':c['case_id'],'full_policies':npol,'exact_optimum':str(brute),'all_5_agree':True,'current_and_future_demand_positive':True})
    dump(BASE/'raw'/'independent_policy_oracle.json',{'cases':records,'total_complete_policies':total_policies,'objective_mismatches':0})
    return {'cases':len(records),'total_complete_policies':total_policies,'objective_mismatches':0}

def run():
    proto=check_freeze()
    raw=[];result_cases=[]
    input_cases=[json.loads((BASE/'instances'/name).read_text()) for name in sorted(proto['input_files_sha256'])]
    for cidx,c in enumerate(input_cases):
        res={m:[] for m in METHODS}
        for rep in range(proto['repetitions']):
            seq=list(METHODS);offset=(rep+cidx)%len(seq);seq=seq[offset:]+seq[:offset]
            for mode in seq:
                p=Problem(c);solver=Solver(p,mode)
                start=time.perf_counter_ns()
                best=solver.value(*p.initial)
                dur=time.perf_counter_ns()-start
                record={'case_id':c['case_id'],'split':c['split'],'family':c['family'],'repeat':rep,'mode':mode,
                        'value':str(best),'root_action':{'z':solver.last_root_action.z,'u':solver.last_root_action.u,'cost':solver.last_root_action.kappa},
                        'runtime_ns':dur,'states':solver.stats['expanded_states'],'candidate_actions':solver.stats['candidate_actions'],
                        'retained_actions':solver.stats['retained_actions'],'pruned_actions':solver.stats['pruned'],
                        'pair_attempts':solver.stats['pair_attempts'],'terminal_pair_checks':solver.stats['terminal_pair_checks'],
                        'structural_branch_certs':solver.stats['structural_branch_certs'],
                        'knapsack_cert_checks':solver.stats['knapsack_cert_checks'],
                        'enumerative_cert_checks':solver.stats['enumerative_cert_checks']}
                raw.append(record);res[mode].append(record)
        ref=res['B0_EXACT'][0]
        for method in METHODS:
            for r in res[method]:
                assert r['value']==ref['value'],(c['case_id'],method,'value mismatch',r['value'],ref['value'])
                assert r['root_action']==ref['root_action'],(c['case_id'],method,'root mismatch',r['root_action'],ref['root_action'])
                assert r['candidate_actions']==r['pruned_actions']+r['retained_actions'],(c['case_id'],method,'count mismatch')
        result_cases.append({'case_id':c['case_id'],'split':c['split'],'family':c['family'],'k':c['k'],'N':c['N'],'T':c['T'],
          'positive_demand_all_scenarios_all_periods':True,'exact_value':ref['value'],'baseline_states':ref['states'],
          'methods':{m:{'median_runtime_ns':statistics.median(x['runtime_ns'] for x in res[m]),
                       'median_states':statistics.median(x['states'] for x in res[m]),
                       'median_pruned':statistics.median(x['pruned_actions'] for x in res[m]),
                       'median_pairs':statistics.median(x['pair_attempts'] for x in res[m])} for m in METHODS}})
        print(f"{cidx+1}/{len(input_cases)} {c['case_id']} exact {ref['value']} pruning F1={res['BF1'][0]['pruned_actions']} F2={res['BF2'][0]['pruned_actions']} F3={res['BF3'][0]['pruned_actions']}",flush=True)
    micro=policy_micro_oracle()
    dump(BASE/'raw'/'all_trials.json',raw);dump(BASE/'raw'/'per_instance.json',result_cases)
    ratio={};family_aggregation={}
    for method in METHODS[1:]:
        log_ratios=[];speeds=[]
        for result in result_cases:
            b=result['methods']['B0_EXACT']['median_runtime_ns'];a=result['methods'][method]['median_runtime_ns']
            log_ratios.append(math.log(b/a));speeds.append(b/a)
        ratio[method]={'geomean_B0_div_method':math.exp(statistics.mean(log_ratios)),
                       'median_B0_div_method':statistics.median(speeds),
                       'instances_method_faster':sum(x>1 for x in speeds),'instances_total':len(speeds),
                       'mean_pruned_actions_per_instance':statistics.mean(z['methods'][method]['median_pruned'] for z in result_cases),
                       'mean_states_per_instance':statistics.mean(z['methods'][method]['median_states'] for z in result_cases)}
        for family in FAMILIES:
            rr=[r for r in result_cases if r['family']==family]
            family_aggregation.setdefault(family,{})[method]={'geomean_B0_div_method':math.exp(statistics.mean(math.log(r['methods']['B0_EXACT']['median_runtime_ns']/r['methods'][method]['median_runtime_ns']) for r in rr)),
                'mean_actions_pruned':statistics.mean(r['methods'][method]['median_pruned'] for r in rr),
                'instances_with_pruning':sum(r['methods'][method]['median_pruned']>0 for r in rr)}
    # deterministic nonparametric bootstrap clustered by instance (not by trials)
    rr=random.Random(SEED+5);ci={}
    for method in METHODS[1:]:
        logs=[math.log(r['methods']['B0_EXACT']['median_runtime_ns']/r['methods'][method]['median_runtime_ns']) for r in result_cases]
        boots=[]
        for z in range(1200):
            inds=[rr.randrange(len(logs)) for _ in logs]
            boots.append(math.exp(sum(logs[j] for j in inds)/len(logs)))
        boots.sort();ci[method]={'instance_cluster_bootstrap_95pct':[boots[30],boots[1169]],'bootstrap_samples':1200}
    summary={'protocol_id':proto['protocol_id'],'protocol_sha256':sha_file(PROTOCOL),'instances':len(input_cases),
       'development_cases':24,'evaluation_cases':12,'total_runs':len(raw),'exact_objective_mismatches':0,'root_action_mismatches':0,
       'all_cases_positive_demands_each_scenario_each_period':True,'independent_policy_micro_oracle':micro,
       'ratio':ratio,'bootstrap_ci':ci,'by_family':family_aggregation,'source_skill02_holdout_used':False,
       'repetitions':proto['repetitions'],'method_names':METHODS,
       'environment':{'python':platform.python_version(),'OS':platform.platform(),'cpu_count':os.cpu_count(),'implementation':'CPython stdlib Fraction'},
       'runtime_measurement_note':'Whole Python solver per trial within a warm process; includes certificate costs, not Python startup or filesystem I/O. Small timing results are noisy.',
       'limits':'Fixed feasible deterministic dispatcher, no jointly optimized routing, small synthetic instances, no general performance inference.'}
    dump(BASE/'raw'/'J3_SUMMARY.json',summary)
    print('SUMMARY_JSON',json.dumps({'cases':summary['instances'],'runs':len(raw),'policy_oracle':micro,'ratio':ratio,'ci':ci},ensure_ascii=False),flush=True)

def inspect():
    print(json.dumps({'protocol_sha256':sha_file(PROTOCOL),'code_sha256':sha_file(Path(__file__)),
     'instances':len(list((BASE/'instances').glob('*.json')))},indent=2))

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('command',choices=('prepare','run','inspect'));args=a.parse_args()
    if args.command=='prepare':prepare()
    elif args.command=='run':run()
    else:inspect()
