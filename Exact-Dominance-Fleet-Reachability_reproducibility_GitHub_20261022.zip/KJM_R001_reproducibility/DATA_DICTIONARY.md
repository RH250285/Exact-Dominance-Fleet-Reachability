# Data and output guide

- `J3/instances/*.json`: original frozen model instances. Four families: `slack_local`, `overload_routing`, `partial_opening`, `long_horizon` (9 each). The `split` of a case is the development (indices 00..05) or evaluation (indices 06..08) partition.
- `J3/protocol/EXPERIMENT_PROTOCOL.json`: experiment seed `2026112103`, immutable code and input SHA-256 digests, protocol ID, model and timing convention.
- `J3/raw/all_trials.json`: array of 540 records, containing `case_id`, `family`, `split`, `repeat`, `mode`, exact `value` stored as a fraction-compatible string, `root_action`, `runtime_ns`, `states`, `candidate_actions`, `pruned_actions`, and comparison counters.
- `J3/raw/per_instance.json`: one entry per case, with cross-method medians and exact objective checks.
- `J3/raw/J3_SUMMARY.json`: original summary, 1200-resample bootstrap confidence intervals and aggregate metrics. Retained as originally produced.
- `J3/raw/independent_policy_oracle.json`: 12 tiny cases, 85 complete policies, no objective mismatches.
- `J3/report/J3_TABLE_MAIN.csv`: original manuscript table; use numerical values from this file, not re-runs on a new machine.
- `J2/raw/*.json`: verification output for structural F1–F4 tests, countermodels, large binary instances, and retained-comparator pruning checks.
- `J2/report/J2_PROOF_LEDGER.csv`: links tested properties to theorem assumptions and boundary conditions.

The original time ratios are paired comparisons and do not imply asymptotic speedups. `runtime_ns` includes solver/pruning work, excluding process start, JSON parsing, and disk I/O. Check `J3/protocol/EXPERIMENT_PROTOCOL.json` for exact timing and split definitions.
