# KJM R001 — Reproducibility materials for reviewers and editors

**Paper:** *Exact Dominance and Budget-Restricted Fleet Reachability in Lagged Facility–Fleet Adaptation* (English working title). This is the source-data/code companion to the manuscript; the current edited Indonesian manuscript lives separately in the author's Google Drive.

## What is included

| Location | Purpose |
|---|---|
| `J2/code/` | Four independent Python verification programs for mathematical claims F1–F4 and boundary cases |
| `J2/raw/`, `J2/report/` | Stored exact-validation summaries, console traces, proof ledger, and mathematical verification report |
| `J3/code/` | Frozen exact Bellman experiment with B0, BTERM, BF1, BF2, BF3; independent report/figure generator |
| `J3/instances/` | All 36 materialized synthetic problem instances (four families, nine each) |
| `J3/protocol/` | Frozen protocol, seed, source-code hash, 36 input hashes, evaluation design |
| `J3/raw/` | Original 540-run records and summaries, 36-instance records, small policy oracle, console log |
| `J3/report/`, `J3/figures/` | Results Table 1 (CSV), technical reports, and historical source figure files |
| `scripts/verify_package.py` | Read-only SHA-256 and exact-consistency checks; does **not** rerun experiments |
| `SOURCE_PROVENANCE.json`, `SHA256SUMS.txt` | Source Drive archive references and checksums for this reviewer package |

The manuscript's **current Figure 1 (paired speed ratios)** corresponds to the original experiment file `J3/figures/Figure_J3_2_Paired_Speed_Ratios.png`. The experiment file `Figure_J3_1_Expanded_States.png` remains as a supplementary output, but its separate figure was removed from the manuscript because Table 1 already reports mean expanded-state counts.

## Quick review without running the experiments

Python 3.11+ (standard library only):

```bash
python scripts/verify_package.py
```

The test checks package integrity, frozen protocol/source/instance integrity, **36 distinct instances × 5 methods × 3 repetitions = 540** historical trials, exact agreement of objective values and first root decisions with B0, independently enumerated policy oracle results, and stored J2 error counts. It does **not** certify mathematical proofs; refer to the paper and `J2/report/J2_PROOF_LEDGER.csv` for their assumptions.

## Re-running the computations

From the extracted repository root, using Python 3.11+:

```bash
# Mathematical verification (J2)
python J2/code/j2_independent_verifier.py
python J2/code/j2_boundary_challenges.py
python J2/code/j2_policy_pool_oracle.py
python J2/code/j2_binary_large.py

# Confirm frozen J3 sources and then rerun the exact experiments
python J3/code/j3_experiment.py inspect
python J3/code/j3_experiment.py run

# Rebuild summaries, table and figure assets from the J3 result files
python J3/code/j3_reporting.py
```

**Run these commands on a disposable working copy.** J2 writes some `J2/raw/*.json` files and J3 re-execution overwrites benchmark outputs in `J3/raw/`. `J3/code/j3_experiment.py prepare` MUST NOT be invoked on the frozen 36 inputs. Re-running the performance experiment will produce different machine-dependent times and potentially different bootstrap confidence intervals; the published historical figures and values should be judged from the original files under `J3/raw/`. The code uses standard-library exact `fractions.Fraction` arithmetic for values; `j3_reporting.py` uses `matplotlib` optionally to regenerate plots.

## Findings and scope

All historical full runs agree in their conditional optimum and lexicographically first optimal root action. Mean expanded states fall from **59.03 (B0)** to **34.08 (BF3)**. The original BF3/B0 paired geometric speed ratio is **1.005**, with 95% cluster-bootstrap CI **[0.959, 1.054]**; this does not establish a general speed advantage. These experiments use small synthetic instances and a fixed H-D-compatible dispatcher rather than jointly optimized routing.

## Public archive and licensing

This package is ready to extract into a GitHub repository. **GitHub does not automatically unpack a ZIP into repository files**: unzip locally, then add the extracted files to the repository. No DOI, GitHub URL, commit hash, or publication date of a public release is asserted here. Record a fixed commit/release and, if desired, archive it with Zenodo for a persistent DOI after the author publishes the repository. The author should choose a software/data license before public release; no license is inferred here.

The files were repackaged from the source ZIPs available in the author-designated Google Drive folder, excluding the compiled `J2/code/__pycache__` directory. No source code, instance, numerical summary, or reported measurement was rewritten during curation. Only the J2 manifest was regenerated to match this cleaned file list; the original archive checksums are recorded in `SOURCE_PROVENANCE.json`.
