#!/usr/bin/env python3
"""Independent contingent-policy expansion and valid common-parent pruning checks."""
from itertools import product
from random import Random
from fractions import Fraction as F
from collections import defaultdict
from j2_independent_verifier import FixedDOracle, dist, belief_update, fleets
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];R=Random(20261123)

def enumerate_all_policies_T2(oracle,x,n,back,Q):
  # Enumerates root action and BOTH contingent stage-1 actions for signals y=0 and y=1.
  # Each stage-1 action is taken after y=0 or y=1; no action is allowed to depend on latent omega.
  beta=oracle.belief;h0,plus0=oracle.dispatch(0,beta,n,back)
  sig=[belief_update(beta,y) for y in (0,1)]
  candidates=[]; policy_count=0
  for z0,u0,c0 in oracle.actions(x,n,Q):
    children=[]
    for y in (0,1):
      py,by=sig[y]
      h1,plus1=oracle.dispatch(1,by,u0,plus0)
      branch=[]
      for z1,u1,c1 in oracle.actions(z0,u0,Q-c0):
         terminal=sum((belief_update(by,y2)[0]*oracle.dispatch(2,belief_update(by,y2)[1],u1,plus1)[0] for y2 in (0,1)),F(0))
         branch.append((z1,u1,c1,h1+c1+terminal))
      children.append(branch)
    for branch0,branch1 in product(children[0],children[1]):
      policy_count+=1
      val=h0+c0+sig[0][0]*branch0[3]+sig[1][0]*branch1[3]
      candidates.append(val)
  assert policy_count
  return min(candidates),policy_count

def policy_vs_bellman():
  total=0; trees=0;routing=0;sample=[]
  for c in range(64):
    k=2;N=R.choice((1,2));T=2;m=R.choice((0,1,2));pen=R.choice((2,5,9));lam=R.choice((1,2))
    demand=tuple(tuple(tuple(R.randint(0,2) for i in range(k)) for w in range(2)) for t in range(3))
    opening=tuple(R.randint(0,2) for i in range(k))
    mode='routing' if c%2 else 'local'
    oracle=FixedDOracle(k,N,T,demand,opening,pen,m,lam,dispatch_mode=mode)
    fleet=R.choice(list(fleets(k,N)))
    x=tuple(1 if fleet[i]>0 or R.random()<.3 else 0 for i in range(k))
    Q=R.randint(0,4)
    back=((0,0),(0,0))
    policy_opt,pcount=enumerate_all_policies_T2(oracle,x,fleet,back,Q)
    bellman=oracle.value(0,oracle.belief,x,fleet,back,Q)
    assert policy_opt==bellman,(c,policy_opt,bellman)
    total+=1;trees+=pcount;routing+=int(mode=='routing')
    if len(sample)<8:sample.append({'case':c,'fleet':fleet,'x':x,'Q':Q,'N':N,'T':T,'m':m,'value':str(bellman),'full_policy_count':pcount,'mode':mode})
  return {'small_three_period_instances':total,'complete_nonanticipative_policies_enumerated':trees,'routing_cases':routing,'optimum_mismatches':0,'examples':sample}

def is_cert_child(oracle,alphaA,alphaB,plus0,Q,by):
  zA,a,cA=alphaA; zB,b,cB=alphaB
  if any(zA[i]<zB[i] for i in range(oracle.k)):return False
  QA=Q-cA;QB=Q-cB
  hA,ba=oracle.dispatch(1,by,a,plus0)
  hB,bb=oracle.dispatch(1,by,b,plus0)
  if ba!=bb:return False
  actsB=list(oracle.actions(zB,b,QB))
  if any(dist(a,u)>oracle.m for z,u,p in actsB):return False
  diffs=[]
  for z,u,pB in actsB:
    zmatch=tuple(max(zA[i],z[i]) for i in range(oracle.k))
    pA=sum(oracle.f[i]*(zmatch[i]-zA[i]) for i in range(oracle.k))+oracle.lam*dist(u,a)
    diffs.append(pA-pB)
  delta=max([0]+diffs)
  return QA>=QB+delta and cA+hA+delta<=cB+hB

def root_pools():
  totals=defaultdict(int); samples=[]
  for c in range(220):
    k=3;N=2 if c%2 else 3;T=2;m=1;lam=1
    allx=(1,1,1);n=R.choice(list(fleets(k,N)))
    # A common root with t0 zero demand, then nonzero scenario-indexed demand later.
    demands=[((0,0,0),(0,0,0))]
    for t in (1,2):
       ds=tuple(tuple(R.randint(0,2) for _ in range(k)) for w in range(2))
       demands.append(ds)
    oracle=FixedDOracle(k,N,T,tuple(demands),(0,0,0),R.choice((2,5,10)),m,lam,dispatch_mode=('routing' if c%4==0 else 'local'))
    Q=R.randint(1,5);back=((0,0,0),(0,0,0));beta=oracle.belief
    h0,plus0=oracle.dispatch(0,beta,n,back)
    alphas=sorted(list(oracle.actions(allx,n,Q)),key=lambda x:(x[2],x[1]))
    sig=[belief_update(beta,y) for y in (0,1)]
    vals={a: h0+a[2]+sum((sig[y][0]*oracle.value(1,sig[y][1],a[0],a[1],plus0,Q-a[2]) for y in (0,1)),F(0)) for a in alphas}
    all_best=min(vals.values()); retained=[];deleted=[]
    for B in alphas:
      witness=next((A for A in retained if all(is_cert_child(oracle,A,B,plus0,Q,sig[y][1]) for y in (0,1))),None)
      if witness is not None:
        assert vals[witness]<=vals[B]
        deleted.append((witness,B))
      else:retained.append(B)
    assert min(vals[a] for a in retained)==all_best
    totals['root_instances']+=1
    totals['root_actions_total']+=len(alphas)
    totals['certified_root_prunings']+=len(deleted)
    totals['root_instances_with_pruning']+=int(bool(deleted))
    totals['optimal_minimum_matches']+=1
    if deleted and len(samples)<10:samples.append({'case':c,'N':N,'n0':n,'Q':Q,'retained':len(retained),'deleted':len(deleted),'full_optimum':str(all_best),'one_witness':str(deleted[0][0]),'one_deleted':str(deleted[0][1])})
  return dict(totals),samples

if __name__=='__main__':
  p=policy_vs_bellman();q,samples=root_pools()
  data={'policy_tree_oracle':p,'common_parent_pool_pruning':q,'pruning_samples':samples,'errors':0,'seed':20261123}
  (ROOT/'raw'/'j2_policy_tree_and_root_pool.json').write_text(json.dumps(data,indent=2,ensure_ascii=False))
  print(json.dumps(data,indent=2,ensure_ascii=False))
