#!/usr/bin/env python3
"""Large binary-integer stress, independent dual subset-support oracle for fleet-ball inclusion."""
import random,json,pathlib
from itertools import combinations
from j2_independent_verifier import ksubset
R=random.Random(20261124)
ROOT=pathlib.Path(__file__).resolve().parents[1]

def composition(k,N):
  # Equal probabilities not required; produces exact integer fleet on enormous N.
  cuts=sorted([0,N]+[R.randrange(N+1) for _ in range(k-1)])
  return tuple(cuts[i+1]-cuts[i] for i in range(k))

def independent_support_max(a,b,r):
  # Derived from maximum aggregate mass that may be shifted into any proper subset S.
  # Unlike F3 knapsack, enumerates EVERY subset, without filtering by profits/capacity.
  k=len(a);N=sum(a);mx=0
  for mask in range(1,(1<<k)-1):
    aa=sum(a[i] for i in range(k) if mask&(1<<i))
    bb=sum(b[i] for i in range(k) if mask&(1<<i))
    mx=max(mx,min(N,bb+r)-aa)
  return mx

if __name__=='__main__':
 n=2600; positive=negative=0;maxN=0;maxK=0;boundaries=0
 for j in range(n):
   k=R.randint(2,8);N=R.randint(10**6,10**12);maxN=max(N,maxN)
   a=composition(k,N);b=composition(k,N)
   m=R.randint(0,N);r=R.randint(0,m)
   if j%5==0:r=m
   if j%7==0:m=N;r=R.randint(0,m)
   bound=ksubset(a,b,m)<=m-r
   support=independent_support_max(a,b,r)<=m
   assert bound==support,(j,k,N,a,b,r,m,bound,support)
   positive+=int(bound);negative+=int(not bound)
   maxK=max(maxK,k);boundaries+=int(r==m or m==N)
 result={'large_binary_inputs':n,'dimension_max':maxK,'max_N':maxN,'inclusions':positive,'noninclusions':negative,'r_equals_m_or_m_equals_N':boundaries,'oracle':'all-subset independent support maxima (not F3 knapsack)','errors':0,'seed':20261124}
 (ROOT/'raw'/'j2_binary_large_summary.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result,indent=2))
