#!/usr/bin/env python3
"""Directed-metric and necessity/countermodel audit; independent of Skill01–02 code."""
from itertools import product
from random import Random
import json, pathlib
from j2_independent_verifier import fleets, dist, FixedDOracle, F

ROOT=pathlib.Path(__file__).resolve().parents[1]
R=Random(20261122)

def directed_metric_checks():
   counts={'triangular_directed_metrics':0,'applicable_BF_R_pairs':0,'envelope_equalities':0,'nontrivial_asymmetric':0,'nonallactive':0,'zero_surcharge':0}
   for run in range(120):
    N=2;k=3;space=list(fleets(k,N));count=len(space)
    weights=[[0 if i==j else R.randint(1,10) for j in range(count)] for i in range(count)]
    for z in range(count):
     for i in range(count):
      for j in range(count):weights[i][j]=min(weights[i][j], weights[i][z]+weights[z][j])
    lookup={v:i for i,v in enumerate(space)}
    def c(target,origin):return weights[lookup[origin]][lookup[target]]
    for a in space:
     for b in space:
      m=R.randint(0,N)
      xb=tuple(1 if b[i]>0 or R.random()<.4 else 0 for i in range(k))
      xa=tuple(1 if a[i]>0 or xb[i] or R.random()<.3 else 0 for i in range(k))
      f=[R.randint(0,5) for i in range(k)]
      QB=R.randint(0,15)
      cand=[]
      for z in product([0,1],repeat=k):
       if any(z[i]<xb[i] for i in range(k)):continue
       for u in space:
        if any(u[i] and not z[i] for i in range(k)) or dist(u,b)>m:continue
        costB=sum(f[i]*(z[i]-xb[i]) for i in range(k))+c(u,b)
        if costB>QB:continue
        az=tuple(max(xa[i],z[i]) for i in range(k))
        costA=sum(f[i]*(az[i]-xa[i]) for i in range(k))+c(u,a)
        cand.append((z,u,costB,costA))
      assert cand # hold in all cases
      if not all(dist(a,u)<=m for z,u,bprice,aprice in cand):continue
      counts['applicable_BF_R_pairs']+=1
      delta=max([0]+[aprice-bprice for z,u,bprice,aprice in cand])
      expected=c(b,a)
      assert delta==expected,(a,b,delta,expected)
      counts['envelope_equalities']+=1
      counts['nontrivial_asymmetric']+=int(c(a,b)!=c(b,a))
      counts['nonallactive']+=int(xa!=(1,1,1) or xb!=(1,1,1))
      counts['zero_surcharge']+=int(expected==0)
    counts['triangular_directed_metrics']+=1
   return counts

def negative_guard_challenges():
  # Missing Q reserve, with true geometry/C2/H-D but false numerical value bound.
  A=FixedDOracle(2,1,1,(((0,0),(0,0)),((1,0),(1,0))),(0,0),10,1,1)
  beta=(F(1,2),F(1,2));back=((0,0),(0,0));xa=xb=(1,1)
  a=(0,1); b=(1,0)
  hA,pA=A.dispatch(0,beta,a,back);hB,pB=A.dispatch(0,beta,b,back)
  VA=A.value(0,beta,xa,a,back,0);VB=A.value(0,beta,xb,b,back,0)
  gamma=1
  assert pA==pB and VA-VB>hA-hB+gamma and VA==10 and VB==0
  no_reserve={'a':a,'b':b,'QA':0,'QB':0,'Gamma':gamma,'VA':str(VA),'VB':str(VB),'hA':str(hA),'hB':str(hB),'fails':'C4: QA >= QB + Gamma'}
  # Missing C2, with otherwise aligned fleet, reserve, identical H-D, but prior backlog differs.
  B=FixedDOracle(2,1,1,(((0,0),(0,0)),((0,0),(0,0))),(0,0),10,0,1)
  a=b=(1,0);BA=((0,1),(0,1));BB=((0,0),(0,0));x=(1,1)
  ha,pa=B.dispatch(0,beta,a,BA);hb,pb=B.dispatch(0,beta,b,BB)
  vA=B.value(0,beta,x,a,BA,0);vB=B.value(0,beta,x,b,BB,0)
  assert pa!=pb and vA-vB>ha-hb and vA==20 and vB==0
  no_coalescence={'a':a,'b':b,'BA':BA,'BB':BB,'VA':str(vA),'VB':str(vB),'hA':str(ha),'hB':str(hb),'Gamma':0,'fails':'C2: post-dispatch backlog bundle equality'}
  # H-D compatibility is needed: a bad feasible dispatcher can depend on idle-open flag.
  # Same current fleet, same backlog and belief, current cost0. At terminal, if facility2
  # is open-with-no-fleet, dispatcher ignores unit of demand that could be served by facility1.
  # With facility2 closed, same physical fleet serves the unit; value ordering fails.
  no_HD={'time_t':0,'a_and_b':(1,0),'x_A':(1,1),'x_B':(1,0),'B_plus_equal':True,'Q_A_Q_B':(0,0),'current_hA_hB':(0,0),'terminal_demand':(1,0),'terminal_hA_hB':(10,0),'VA':10,'VB':0,'Gamma':0,'fails':'H-D: dispatcher must not depend on idle-open flags; construction uses a feasible but deliberately inferior dispatch rule'}
  return {'without_reserve':no_reserve,'without_backlog_coalescence':no_coalescence,'without_H_D':no_HD}

if __name__=='__main__':
  result={'directed_metric_F3_a':directed_metric_checks(),'missing_guard_countermodels':negative_guard_challenges(),'errors':0,'seed':20261122}
  (ROOT/'raw'/'j2_directed_metrics_and_countermodels.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
  print(json.dumps(result,indent=2))
