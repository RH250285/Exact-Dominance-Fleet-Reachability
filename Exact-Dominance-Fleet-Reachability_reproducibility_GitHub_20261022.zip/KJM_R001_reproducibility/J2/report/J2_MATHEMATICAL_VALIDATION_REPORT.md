# J2 — Independent mathematical validation of F1–F4

**Study:** KJM–R001, theory-led manuscript track  
**Run:** J2-R001-KJM-20261121-01  
**Audit date:** 21 November 2026  
**Decision:** `J2_PASS_SCOPED` — internally validated mathematical results under the exact source assumptions; not a journal submission guarantee, not a claim of original priority, and not a substitute for human expert proof review.  
**Next stage:** J3 supporting reproducible experiments; J4 manuscript afterward.

## 1. Input, integrity and unchanged decisions

The target Drive folder was inspected before starting J2. The J1 consolidation and its continuity index were read in full. Original theorem source: `FINAL_RESEARCH_HANDOFF_R001_SOURCE.zip`, SHA-256 `70ca59c4f16fb83b3a2ae7fcfb503dbb029d12bb904ebda79fc0c3f6b336d89a`. Final Skill 02 checkpoint: SHA-256 `2613e7df8f955c5e930654572e51a13e90a65745f65d9855fea729c832a57dee`. The R001 source theorem and nested CAMD/NPS/NCPP proof records were inspected. No upstream ZIP, theorem statement or original decision was changed.

Source decisions: Skill 01 NCPP `GO_MANUSCRIPT` (a research-development decision); Skill 02 A5 `REPOSITION`, algorithmic release `NOT_READY`. The manuscript positioning remains mathematical, not an unproven solver speedup. Model: fixed feasible deterministic H-D-compatible dispatcher, irreversible facility opening, finite integer fleet, one-period implementation lag, common exogenous signal/posterior update, pathwise adaptation reserve, scenario-indexed backlog bundle, and appropriate terminal cost. Routing and dispatch are **not jointly optimized**.

## 2. Independent mathematical proof ledger

### L0, L1 and the fixed-dispatch coupling (PASS)

For same-total vectors `u,a ∈ S_N`, the positive coordinate increments equal the negative coordinate decrements. Thus `d(u,a) = 1/2 Σ_i |u_i−a_i| = max_{S⊆[k]}(u(S)−a(S))`. This identity is standard, and the present application does not claim priority for it.

Aligned-continuation lemma L1: take states with the same `(t,β,n,B)` but `x_A ≥ x_B` and `Q_A ≥ Q_B`. From any B action `(z_B,u)` choose A action `(x_A∨z_B,u)` **before** observing the signal. The effective origin fleets coincide, so both movement counts and movement expenditures coincide; the A opening set is a subset of new openings that B would pay for. Hence A's cost is no greater, successor budget order is preserved on every path, the same effective `u` is used after lag one, and, by H-D, common physical dispatch/backlog and posterior propagate on every positive-probability observation branch. Backward induction on remaining periods gives `V_A ≤ V_B`. At `t=T` the terminal service and terminal backlog charge agree, because they do not depend on `Q` or idle active flags. **Verdict:** proof valid under the explicitly retained H-D, pathwise Q, terminal and lag-one restrictions.

### F1 guarded cost dominance (PASS)

At the same time/posterior, assume `x_A≥x_B`, `B_A⁺=B_B⁺` scenario by scenario, full ball inclusion `R_m(b)⊆R_m(a)`, `Q_A≥Q_B+Γ` and H-D throughout. The original bound is `Γ=max(0,max_{u∈R_m(b)}[c(u;a)−c(u;b)])`. Given optimal B action `(z_B,u)`, C3 makes `u` reachable from A and `x_A∨z_B` supports it; the A opening increment costs no more than B's. A's matched cost exceeds B's by at most Γ, so it is affordable with at least B's successor budget. Backlog equality, lag and common signals give the exact aligned hypotheses for L1 on each successor. The resulting comparison is `V_A−V_B ≤ h_A−h_B+Γ`. Add accumulated costs G to certify permanent direct witness deletion if `G_A+h_A+Γ≤G_B+h_B`. The theorem does not yield state-value equality or authorize replacing cached `V_B` by `V_A`. **Verdict:** PASS, including one-step causal order and pathwise reserve.

### F2 affordable-action matching, dominance and nesting (PASS)

Define the **complete affordable feasible set** `𝒜_B`, not merely B's movement ball. Under `BF-R: d(a,u)≤m` for every `(z,u)∈𝒜_B`, use the same canonical map `μ_A(z,u)=(x_A∨z,u)`. Its greatest nonnegative cost excess `Δ_B(A)=max(0,max_{𝒜_B}[κ_A(μ_Aα)−κ_B(α)])` upper-bounds each matched action; `Q_A≥Q_B+Δ` guarantees feasibility and successor reserve order. The F1 alignment argument then proves `V_A−V_B≤h_A−h_B+Δ`. Direct retained witness plus `G_A+h_A+Δ≤G_B+h_B` preserves a common conditional minimum. If original full ball inclusion holds, all B feasible targets satisfy BF-R and, by nonnegative opening fees, `Δ≤Γ`: hence F1 certificates are nested in F2. It is **not** correct to test only a selected B action when claiming the F2 universal condition. **Verdict:** PASS; conditional pool comparability and permanent extant witness are necessary implementation preconditions.

### F3-a exact directed-metric matched surcharge (PASS)

Here `c(u;a)` denotes movement **from a to u**. The directional triangle inequality gives `c(u;a)−c(u;b)≤c(b;a)` for every B action. A's additional opening fees in its canonical match are no greater than B's, hence `Δ≤c(b;a)`. Since the zero-cost hold at B, `(x_B,b)`, belongs to `𝒜_B`, its canonical A match is `(x_A,b)` and (when BF-R holds) is movement-feasible. The difference for this action is *exactly* `c(b;a)`. Therefore `Δ=c(b;a)`. This result can fail for nonmetric movement costs, and it does not by itself decide BF-R. **Verdict:** PASS; orientation, hold attainability and zero diagonal are essential.

### F3-b exact unequal-radius containment (PASS)

For `0≤r≤m≤N`, define positive-discrepancy index set `P={i:b_i>a_i}`, capacity `C=N−m−1`, and `K=max{Σ_{i∈S}(b_i−a_i): S⊆P,Σ_{i∈S}a_i≤C}`, taking `K=0` for C<0. For any **nonempty proper** subset S of coordinates, the maximum attainable mass in S over `R_r(b)` is `min(N,b(S)+r)`; this is attained by moving up to `r` vehicles across the S/complement boundary. The identity L0 therefore rewrites `max_{u∈R_r(b)}d(a,u)` as a maximum over these aggregate masses. If `a(S)≥N−m`, the distance contribution can never exceed m. Otherwise `a(S)≤C`, and exceedance occurs precisely if `b(S)−a(S)>m−r`. Removing coordinates with nonpositive `b_i−a_i` cannot increase weight or lower positive discrepancy; thus a violating set exists iff `K>m−r`. Accordingly `R_r(b)⊆R_m(a) ⇔ K≤m−r`. The k=1 and N=0 cases have singleton fleet spaces; m=N is automatically contained, and the convention K=0 is correct. **Verdict:** PASS, including the proper-subset restriction, empty/full-set boundaries and zero-weight knapsack items.

A descending-capacity 0–1 dynamic program evaluates K exactly in `O(k(N−m))` **integer operations** and `O(N−m)` numeric words for `m<N` (plus `O(k)` input and bit-arithmetic costs); m=N is an immediate yes. This is pseudo-polynomial, not strongly polynomial for binary input; it is a checker bound, not a full belief-state-DP bound.

### F3-c all-active, uniform unit-move budget certificate (PASS)

With all facilities already active, movement expense `λd`, `λ>0`, no other physical action restrictions, B's affordable fleet set is exactly `R_{r_B}(b)` with `r_B=min(m,⌊Q_B/λ⌋)`. F3-b determines BF-R exactly; F3-a gives `Δ=λd(a,b)`. Alongside posterior/time equality, post-dispatch bundle coalescence, H-D, `Q_A≥Q_B+Δ`, a valid common label comparison and a permanently retained witness, this safely deletes a dominated record. The rule is **not** licensed for restricted arcs, extra opening constraints, arbitrary unverified dispatcher ties or nonuniform nonmetric charges. **Verdict:** PASS.

### F4 binary complexity boundary (PASS)

A noncontainment certificate is a vector `u∈S_N` with `d(b,u)≤r` and `d(a,u)>m`, whose binary representation and distance checks are polynomial in the input bit length. Thus NONCONTAINMENT is in NP and containment is in coNP. For a positive 0–1 KNAPSACK instance with weights `w_i`, profits `p_i`, capacity W≤H=`Σ w_i`, integer target P₀≥1 and J=`Σp_i`, form `a=(w_1,...,w_n,J,P₀)`, `b=(w_1+p_1,...,w_n+p_n,0,P₀)`, `N=H+J+P₀`, `m=N−W−1`, `r=m−P₀+1=H+J−W`. Then `0≤r≤m≤N`, and the F3-b positive differences, knapsack weights and capacity are exactly `p_i`, `w_i`, W; the containment threshold is `m−r=P₀−1`. A profitable capacity-feasible subset therefore exists iff NONCONTAINMENT holds. Binary additions and copies yield polynomial reduction size. **Verdict:** NP-completeness of NONCONTAINMENT and coNP-completeness of CONTAINMENT are justified **only for variable k and binary coding**. This does not assert fixed-dimension or equal-radius hardness or the novelty of knapsack hardness itself.

## 3. Independent finite exact validation (new J2 runs, not recycled Skill 01–02 tests)

All J2 scripts were newly authored in Python's standard library and import no TGAD/source research code. We generated exact integer fleets and feasible actions, rational Bayesian probabilities and a common nonanticipative dispatch shipment plan for all latent scenarios; a signal is observed only after its current action is committed. A conservative fixed dispatcher bases shipments on scenario-minimum available quantity, with optional deterministic routing costs. The dispatcher is feasible and H-D-compatible. The tests are an explicitly defined **subclass** of the sourced general model, not a substitute for general proofs.

| Audit | Independent method | Result |
| --- | --- | --- |
| F3-b exact containment | Enumerate all feasible fleet targets `u` and compare directly with independent positive-index subset enumeration **and** descending 0–1 DP, all k=1..4, N=0..6, all a,b,r,m | **325,094 checks, 0 discrepancies** |
| F3-b large binary input | Independent ALL-subsets support-function maximum versus F3 knapsack subset optimization, k=2..8, N up to 999,924,381,164 | **2,600 checks, 0 discrepancies** (not full-ball enumeration for huge N) |
| F4 reduction | Positive knapsack decision by independent subset enumeration; converted containment test via subset K; explicit independent full-ball oracle for manageable instances | **3,781 reductions, 0 discrepancies; 281 direct full-ball cases** |
| F1 value bound | Exact rational finite-horizon Bayesian Bellman with scenario-common feasible dispatcher, pathwise budget | **890 certified comparisons, 0 violations** |
| F2 value bound | Same oracle, **all** B affordable actions included in guard, exact matched surcharge | **1,022 certified comparisons, 0 violations; 132 F2-only cases** |
| F1/F2 structural coverage | Certified pairs above | **646 with positive current demand; 434 with not-all-active facilities; 280 with three periods; 46 with unequal h_A/h_B; 348 routed-dispatch cases** |
| F3-a directed metric | Generate 120 asymmetric shortest-path metrics, enumerate full B action set and matched cost surcharge | **2,316 surcharge identities, 0 violations**, including 1,376 asymmetric cases |
| Independent contingent policy tree | Enumerate complete nonanticipative root and signal-contingent actions, compare with exact rational Bellman | **439 complete policies over 64 three-period problems, 0 optimum mismatches** |
| Real common-parent pruning | Enumerate actual feasible actions from the **same** parent, require certificates for every next-signal branch, keep direct witness | **220 root instances, 944 actions, 167 certified deletions, exact minimum preserved on all 220** |
| Generic retained-core invariant | Independent random ordered numeric record sets | **5,000 trials, 0 minimum mismatches** |

The numbers count comparisons or enumerated policies, not independent proofs. The 890 F1 comparisons are a subset of the 1,022 F2 comparisons; the rows must not be added to imply 1,912 distinct cases. The root-action pool is the separate experiment establishing safe deletion in an actual common conditional minimization; arbitrary cross-state value checks alone would not establish the label-pool condition.

## 4. Necessary-assumption countermodels

**Without C4 pathwise reserve:** Let `k=2`, `N=1`, `m=1`, all facilities open, `a=(0,1)`, `b=(1,0)`, `Q_A=Q_B=0`, uniform movement cost 1, current demand 0, and terminal demand one unit at facility 1 with backlog penalty 10. Current post-dispatch bundles and h are equal, full ball inclusion holds and Γ=1. A cannot afford to relocate, so `V_A=10`, while B can hold and obtains `V_B=0`. The forbidden relaxation predicts `10≤1`, false. The correct original theorem excludes the pair because `Q_A<Q_B+Γ`.

**Without C2 post-dispatch backlog synchronization:** Let `k=2`, `N=1`, `m=0`, identical fleet `(1,0)` and all-active flags, equal budgets 0 and zero movement cost. A has one unit of initial backlog at node 2 in both scenarios, B has zero. With backlog penalty 10 each of two remaining periods and no new demand, `h_A−h_B=10`, Γ=0, yet `V_A−V_B=20`. The incorrect relaxation would assert `20≤10`. Original C2 excludes this example.

**Without H-D:** Both fleets are `(1,0)`, while A opens the idle second facility, B does not. At t=0 there is no demand or backlog, current dispatch/backlog coincide, budget and movement charges vanish. At terminal demand one unit at the first facility arrives. Define a *feasible but deliberately inferior* dispatcher that unnecessarily declines service only when the idle second facility is open. Then A suffers penalty 10 while B serves the demand, contradicting L1. This deliberately non-H-D dispatcher lies outside the source theorem.

**Directed metric orientation:** When `c` is not triangular, the F3-a identity can fail (source NPS counterexample has `c(b;a)=1` but `c(u;a)−c(u;b)=10`). The J2 metric generator instead imposes directed triangle inequalities explicitly by shortest-path closure.

These counterexamples are **outside** original theorem assumptions and demonstrate necessity of keeping those guards; they do not refute the source F1–F4 claims.

## 5. Audit concerns and methodological controls

1. No missing logical step was found within F1–F4 **as stated and scoped**. This is an internal independent reconstruction, not a referee's certification and not a new priority assessment.
2. Nonanticipativity was actively checked: an earlier exploratory draft of the J2 oracle had computed scenario-dependent shipments, which would have revealed latent information. It was rejected and replaced **before the locked J2 run** with a single shipment plan common to all scenarios. Superseded exploratory counts are not the final results; the accompanying code and saved raw outputs implement the corrected model.
3. Finite tests are exact within their generated finite subclasses (integer costs, rational probabilities) and do not prove the general real-valued dispatcher theorem; the formal coupling proofs provide the general argument.
4. The source decomposition limits must remain visible in the manuscript: current dispatch fixed, lag one, same signals, posterior, pathwise reserve, terminal service, and restricted action definitions. All reachability and cost-surcharge antecedents are **jointly necessary for these certificates as written**; the tests do not show each antecedent is individually logically necessary in every possible variant.
5. The known Skill 02 negative timing remains unchanged; none of these J2 proof-validation tests is a fair performance comparison. The 12 archived TGAD final holdout IDs were not opened for tuning, executed or relabeled.
6. J2 scripts verify independent exact results but not KJM editorial suitability or external first-publication originality. Those issues remain separate from mathematical validity.

## 6. Decision and handoff to J3

**J2 final scientific decision: `J2_PASS_SCOPED`.** F1 (fixed-D guarded cost dominance), F2 (full affordable-action matching), F3 (directed-metric envelope, unequal-radius exact containment and all-active budget corollary), and F4 (variable-dimension binary NP/coNP complexity) pass an independent proof audit with no contradiction discovered and extensive fresh exact numerical cross-checks. Theoretical scope and original Skill01/02 decisions remain immutable.

**J3 permission:** proceed with a supporting validation protocol designed for a theorem-led KJM paper. Use explicit independent exact baselines, instances with positive realized demand, backlog, different posterior paths, and demonstrative strict F2 vs F1 certificates. Report dominance-safe deletions, correctness and failure/negative timing with no mandatory runtime speedup claim. Freeze J3 seeds and sample design before J3's final execution. Do **not** use the old TGAD frozen final holdout without a separate authorized protocol and do not recast this J2 work as Skill03 E1–E3.

## 7. Audit artifacts and provenance

- `code/j2_independent_verifier.py`: exact fleet balls, subset and knapsack, positive knapsack reduction, Bayesian Bellman, retained labels.
- `code/j2_boundary_challenges.py`: directed metric tests and guard-removal countermodels.
- `code/j2_policy_pool_oracle.py`: independent complete nonanticipative contingent-policy enumeration and common-parent root-action deletion.
- `code/j2_binary_large.py`: large binary fleet counts and independent subset-support maximum.
- `raw/*.json` and `raw/*console.txt`: machine-readable summarized exact outputs and reproducible console traces.
- `report/J2_PROOF_LEDGER.csv`: per-claim audit verdict and dependencies.
- `J2_STAGE_STATE.json`, `MANIFEST_SHA256.txt`, `README.md`: state, integrity and reproduction instructions.

Primary source documents remain unchanged: R001 discovery document, the Skill01 NCPP handoff, J1 mathematical consolidation and Skill02 final checkpoint. This J2 archive is a new independent validation layer, not an edit to those sources.
