# KJM–R001 / J2 proof verification package

This package was written as a **new independent mathematical audit** for the KJM theory-led manuscript direction. No Skill01/02 source code is imported into these verification programs; those upstream artifacts are immutable.

## Reproduce exact finite cross-checks

Requires Python 3.11+ (standard library only). From the package root, run:

```
python code/j2_independent_verifier.py
python code/j2_boundary_challenges.py
python code/j2_policy_pool_oracle.py
python code/j2_binary_large.py
```

All random seeds are specified in source. Scripts overwrite only their own `raw/*.json` outputs. The stored `raw/*console.txt` files preserve the J2 execution trace. The signed mathematical conclusions are in `report/J2_MATHEMATICAL_VALIDATION_REPORT.md`, and the claim-level ledger is `report/J2_PROOF_LEDGER.csv`.

Source: Skill01 `FINAL_RESEARCH_HANDOFF_R001_SOURCE.zip` SHA256 70ca59c4f16fb83b3a2ae7fcfb503dbb029d12bb904ebda79fc0c3f6b336d89a; historical TGAD final checkpoint SHA256 2613e7df8f955c5e930654572e51a13e90a65745f65d9855fea729c832a57dee.

**Decision:** J2_PASS_SCOPED. No independent manuscript-level referee guarantee. No J3 experiment results, no journal submission and no Speedup claim.
